// Daily Forge 2.0 — application bootstrap, rendering loop, modals
window.Forge = window.Forge || {};

Forge.App = (function () {
  var appEl, rootEl, embersEl;
  var modalEl = null;
  var cursorEl = null;
  var cursorMoveHandler = null;
  var embersBuilt = false;

  var SCREENS = {
    home: Forge.UI.Home,
    character: Forge.UI.Character,
    map: Forge.UI.Map,
    quests: Forge.UI.Quests,
    inventory: Forge.UI.Inventory,
    skills: Forge.UI.Skills,
    bosses: Forge.UI.Bosses,
    achievements: Forge.UI.Achievements,
    calendar: Forge.UI.Calendar,
    log: Forge.UI.Log,
    settings: Forge.UI.Settings
  };

  function boot(uid) {
    rootEl = document.getElementById('forgeRoot');
    appEl = document.getElementById('forgeApp');
    embersEl = document.getElementById('forgeEmbers');

    Forge.State.init(uid).then(afterStateReady);
  }

  // The old body of boot(), minus the (now async, one-time) load — also reused by
  // restart() so Settings' import-backup/wipe-save flows can re-render already-replaced
  // in-memory state without a redundant/racy Firestore re-fetch.
  function afterStateReady() {
    var state = Forge.State.get();
    Forge.Engine.ensureTodayQuests(state);
    var rewards = Forge.Engine.checkSeasonalEvents(state);
    Forge.State.save();
    Forge.Sound.setEnabled(state.settings.soundOn !== false);
    applyCosmetics();
    render();
    announceSeasonalRewards(rewards);
  }

  function render() {
    var state = Forge.State.get();
    var rolledOver = Forge.Engine.ensureTodayQuests(state);
    var rewards = Forge.Engine.checkSeasonalEvents(state);
    if (rolledOver || rewards.length) Forge.State.save();

    var current = Forge.UI.Nav.getCurrent();
    var screen = SCREENS[current] || SCREENS.home;

    var html = Forge.UI.Nav.renderTopbar(state) + screen.render(state) + Forge.UI.Nav.renderBottomNav() + Forge.UI.Nav.renderDrawer(state);
    appEl.innerHTML = html;

    Forge.UI.Nav.bindEvents(appEl);
    screen.mount(appEl, state);
    announceSeasonalRewards(rewards);
  }

  function announceSeasonalRewards(rewards) {
    rewards.forEach(function (r) {
      Forge.UI.Toast.show(r.typeInfo.icon, r.event.title, 'A seasonal gift has arrived.');
      Object.keys(r.granted).forEach(function (matId) {
        var item = Forge.Data.getItem(matId);
        if (item) Forge.UI.Toast.show(item.icon, 'Loot Found', item.name + ' x' + r.granted[matId]);
      });
      if (r.equipment) {
        var equipItem = Forge.Data.getItem(r.equipment);
        if (equipItem) Forge.UI.Toast.show(equipItem.icon, 'New Equipment', equipItem.name);
      }
      Forge.Sound.play('achievement');
    });
  }

  // ---------------- quest completion flow (shared by all screens) ----------------
  function toggleQuest(questId, sourceEl) {
    var state = Forge.State.get();
    var q = state.quests.instances.find(function (x) { return x.id === questId; });
    if (!q) return;

    if (q.done) {
      Forge.Engine.uncompleteQuest(state, questId);
      Forge.State.save();
      render();
      return;
    }

    var result = Forge.Engine.completeQuest(state, questId);
    if (!result) return;
    Forge.State.save();
    Forge.Sound.play('questComplete');
    if (sourceEl) Forge.UI.Toast.xpFloat(sourceEl, result.xpGained);
    Forge.UI.Toast.lootPopup(result.loot);
    if (result.equipmentFound) {
      var equipItem = Forge.Data.getItem(result.equipmentFound);
      Forge.UI.Toast.show(equipItem.icon, 'Rare Find', equipItem.name);
      Forge.Sound.play('achievement');
    }
    if (result.eventReward) {
      Forge.UI.Toast.show(result.eventReward.typeInfo.icon, result.eventReward.event.title, 'Reward earned!');
      Object.keys(result.eventReward.granted).forEach(function (matId) {
        var item = Forge.Data.getItem(matId);
        if (item) Forge.UI.Toast.show(item.icon, 'Loot Found', item.name + ' x' + result.eventReward.granted[matId]);
      });
      if (result.eventReward.equipment) {
        var eventEquipItem = Forge.Data.getItem(result.eventReward.equipment);
        if (eventEquipItem) Forge.UI.Toast.show(eventEquipItem.icon, 'New Equipment', eventEquipItem.name);
      }
      Forge.Sound.play('achievement');
    }
    if (result.leveledUp) Forge.UI.Toast.levelUpPopup(result.newLevel);
    (result.newAchievements || []).forEach(function (a) { Forge.UI.Toast.achievementPopup(a); });
    render();
  }

  // ---------------- modals ----------------
  function closeModal() {
    if (modalEl) { modalEl.remove(); modalEl = null; }
  }

  function openModal(innerHtml) {
    closeModal();
    modalEl = document.createElement('div');
    modalEl.className = 'forge-modal-backdrop';
    modalEl.innerHTML = '<div class="forge-modal">' + innerHtml + '</div>';
    modalEl.addEventListener('click', function (e) { if (e.target === modalEl) closeModal(); });
    rootEl.appendChild(modalEl);
    return modalEl;
  }

  function openReportModal() {
    var state = Forge.State.get();
    var t = state.today;
    var li = Forge.Engine.levelInfo(state.character.totalXP);
    var statsGained = Object.keys(t.statsGained).map(function (k) { return k.charAt(0).toUpperCase() + k.slice(1) + ' +' + t.statsGained[k]; }).join(', ') || 'None yet';
    var lootLines = t.lootFound.map(function (l) { var item = Forge.Data.getItem(l.id); return item ? item.name + ' x' + l.qty : ''; }).join(', ') || 'None yet';
    var achLines = t.achievementsUnlocked.map(function (id) { var a = Forge.Data.ACHIEVEMENTS.find(function (x) { return x.id === id; }); return a ? a.name : ''; }).join(', ') || 'None yet';
    var unlockedAreas = Forge.Engine.unlockedAreas(state);
    var nextArea = Forge.Data.AREAS.find(function (a) { return unlockedAreas.indexOf(a.id) === -1; });
    var destination = nextArea ? nextArea.name + ' (unlocks at Lv ' + nextArea.unlockLevel + ')' : Forge.Data.AREA_NAME(state.position.areaId);

    var html = '<div class="forge-modal-title">Today\'s Expedition</div>';
    html += '<div class="forge-col" style="font-size:13px;">';
    html += '<div class="forge-row" style="justify-content:space-between;"><span style="color:var(--muted);">XP Earned</span><span class="f-mono" style="color:var(--accent);">+' + t.xpEarned + '</span></div>';
    html += '<div class="forge-row" style="justify-content:space-between;"><span style="color:var(--muted);">Loot Found</span><span style="text-align:right;max-width:220px;">' + lootLines + '</span></div>';
    html += '<div class="forge-row" style="justify-content:space-between;"><span style="color:var(--muted);">Stats Gained</span><span>' + statsGained + '</span></div>';
    html += '<div class="forge-row" style="justify-content:space-between;"><span style="color:var(--muted);">Achievements</span><span>' + achLines + '</span></div>';
    html += '<div class="forge-divider"></div>';
    html += '<div class="forge-row" style="justify-content:space-between;"><span style="color:var(--muted);">Tomorrow\'s Destination</span><span>' + destination + '</span></div>';
    html += '</div>';
    html += '<button class="forge-btn forge-btn-primary forge-btn-block" style="margin-top:16px;" data-modal-close="1">Close</button>';

    var el = openModal(html);
    el.querySelector('[data-modal-close]').addEventListener('click', closeModal);
  }

  function openEquipModal(slot) {
    var state = Forge.State.get();
    var owned = state.equipment.owned.filter(function (id) { var it = Forge.Data.getItem(id); return it && it.slot === slot; });
    var currentId = state.equipment.slots[slot];

    var html = '<div class="forge-modal-title">' + slot.charAt(0).toUpperCase() + slot.slice(1) + '</div>';
    if (!owned.length) {
      html += '<div class="forge-empty">No ' + slot + ' items owned yet. Craft or find one.</div>';
    } else {
      html += '<div class="forge-col">';
      owned.forEach(function (id) {
        var item = Forge.Data.getItem(id);
        var equipped = currentId === id;
        html += '<div class="forge-row" style="justify-content:space-between;padding:10px;border:1px solid ' + (equipped ? 'var(--accent-dim)' : 'var(--line)') + ';border-radius:8px;">';
        html += '  <span class="forge-row">' + Forge.Icons.svg(item.icon) + '<span>' + item.name + ' <span style="color:var(--ok);font-size:11px;">+' + item.bonus.amount + ' ' + item.bonus.stat + '</span></span></span>';
        html += equipped ? '<button class="forge-btn" data-unequip="1">Unequip</button>' : '<button class="forge-btn forge-btn-primary" data-equip="' + id + '">Equip</button>';
        html += '</div>';
      });
      html += '</div>';
    }
    html += '<button class="forge-btn forge-btn-block" style="margin-top:12px;" data-modal-close="1">Close</button>';

    var el = openModal(html);
    el.querySelectorAll('[data-equip]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        Forge.Engine.equipItem(state, btn.getAttribute('data-equip'));
        Forge.State.save();
        Forge.Sound.play('click');
        closeModal();
        render();
      });
    });
    var unequipBtn = el.querySelector('[data-unequip]');
    if (unequipBtn) unequipBtn.addEventListener('click', function () {
      Forge.Engine.unequipItem(state, slot);
      Forge.State.save();
      closeModal();
      render();
    });
    el.querySelector('[data-modal-close]').addEventListener('click', closeModal);
  }

  function rewardPreviewHtml(typeInfo) {
    var mats = Object.keys(typeInfo.materials).map(function (matId) {
      var item = Forge.Data.getItem(matId);
      return (item ? item.name : matId) + ' x' + typeInfo.materials[matId];
    }).join(', ');
    var buff = Forge.Data.BUFFS[typeInfo.buff];
    var equipItem = typeInfo.equipment ? Forge.Data.getItem(typeInfo.equipment) : null;
    return 'Reward: ' + mats + ', plus ' + (buff ? buff.name : typeInfo.buff) + '.' +
      (equipItem ? ' Also unlocks ' + equipItem.name + ' (first time only).' : '');
  }

  function areaOptionsHtml(selected) {
    return Forge.Data.AREAS.map(function (a) {
      return '<option value="' + a.id + '"' + (a.id === selected ? ' selected' : '') + '>' + a.name + '</option>';
    }).join('');
  }

  function statOptionsHtml() {
    return ['strength', 'knowledge', 'discipline', 'vitality', 'creativity', 'social'].map(function (s) {
      return '<option value="' + s + '">' + s.charAt(0).toUpperCase() + s.slice(1) + '</option>';
    }).join('');
  }

  function eventStatusLine(e) {
    if (e.quest) {
      if (e.rewardState === 'granted') return 'Reward earned — "' + e.quest.title + '" was completed.';
      if (e.rewardState === 'missed') return 'Reward missed — "' + e.quest.title + '" wasn’t completed in time.';
      return 'Tied quest: "' + e.quest.title + '". Complete it that day to earn the reward.';
    }
    return e.rewardState === 'granted' ? 'Reward claimed.' : 'Reward granted automatically on the day.';
  }

  function openEventModal(dateStr) {
    var state = Forge.State.get();
    var existing = state.calendar.events.filter(function (e) { return e.date === dateStr; });

    var html = '<div class="forge-modal-title">' + dateStr + '</div>';
    if (existing.length) {
      html += '<div class="forge-col" style="margin-bottom:12px;">';
      existing.forEach(function (e) {
        html += '<div style="padding:8px;border:1px solid var(--line);border-radius:8px;">' +
          '<div class="forge-row" style="justify-content:space-between;"><span>' + e.title + '</span><button class="forge-btn-ghost" data-modal-remove-event="' + e.id + '" style="font-size:14px;">×</button></div>' +
          '<div style="font-size:10.5px;color:var(--muted);margin-top:2px;">' + eventStatusLine(e) + '</div>' +
          '</div>';
      });
      html += '</div>';
    }
    html += '<div class="forge-field"><label class="forge-label">Event Name</label><input class="forge-input" id="evTitle" maxlength="40" placeholder="e.g. Halloween, Cosplay Con, Winter Festival" /></div>';
    html += '<div class="forge-field"><label class="forge-label">Event Type</label><select class="forge-select" id="evType">' +
      Forge.Data.EVENT_TYPES.map(function (t) { return '<option value="' + t.id + '">' + t.label + '</option>'; }).join('') + '</select></div>';
    html += '<div id="evRewardHint" style="font-size:11px;color:var(--muted);margin:-6px 0 12px;">' + rewardPreviewHtml(Forge.Data.EVENT_TYPES[0]) + '</div>';

    html += '<div class="forge-divider" style="margin:4px 0 12px;"></div>';
    html += '<label class="forge-checkline"><input type="checkbox" id="evTieQuest" /> Tie a one-time quest — the reward only unlocks if it’s completed that day</label>';
    html += '<div id="evQuestFields" class="forge-hide">';
    html += '  <div class="forge-field"><label class="forge-label">Quest Name</label><input class="forge-input" id="evQTitle" maxlength="60" placeholder="e.g. Finish the costume" /></div>';
    html += '  <div class="forge-field"><label class="forge-label">Description</label><textarea class="forge-textarea" id="evQFlavor" maxlength="200" placeholder="Optional flavor text"></textarea></div>';
    html += '  <div class="forge-grid-2">';
    html += '    <div class="forge-field"><label class="forge-label">Area</label><select class="forge-select" id="evQArea">' + areaOptionsHtml('homeVillage') + '</select></div>';
    html += '    <div class="forge-field"><label class="forge-label">Stat</label><select class="forge-select" id="evQStat">' + statOptionsHtml() + '</select></div>';
    html += '  </div>';
    html += '  <div class="forge-field"><label class="forge-label">XP Reward</label><input class="forge-input" id="evQXp" type="number" min="1" max="500" value="25" /></div>';
    html += '</div>';

    html += '<div class="forge-grid-2" style="margin-top:8px;">';
    html += '  <button class="forge-btn forge-btn-ghost forge-btn-block" data-modal-close="1" style="padding:13px;">Close</button>';
    html += '  <button class="forge-btn forge-btn-primary forge-btn-block" id="evSubmit" style="padding:13px;">Add Event</button>';
    html += '</div>';

    var el = openModal(html);
    el.querySelector('[data-modal-close]').addEventListener('click', closeModal);
    el.querySelectorAll('[data-modal-remove-event]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        Forge.Engine.removeCalendarEvent(state, btn.getAttribute('data-modal-remove-event'));
        Forge.State.save();
        closeModal();
        render();
      });
    });
    var typeSelect = el.querySelector('#evType');
    typeSelect.addEventListener('change', function () {
      el.querySelector('#evRewardHint').textContent = rewardPreviewHtml(Forge.Data.getEventType(typeSelect.value));
    });
    var tieCheckbox = el.querySelector('#evTieQuest');
    var questFields = el.querySelector('#evQuestFields');
    tieCheckbox.addEventListener('change', function () {
      questFields.classList.toggle('forge-hide', !tieCheckbox.checked);
    });
    var submitBtn = el.querySelector('#evSubmit');
    submitBtn.addEventListener('click', function () {
      var title = el.querySelector('#evTitle').value.trim();
      if (!title) return;
      var quest = null;
      if (tieCheckbox.checked) {
        var qTitle = el.querySelector('#evQTitle').value.trim();
        if (qTitle) {
          quest = {
            title: qTitle,
            flavor: el.querySelector('#evQFlavor').value.trim(),
            area: el.querySelector('#evQArea').value,
            stat: el.querySelector('#evQStat').value,
            xp: parseInt(el.querySelector('#evQXp').value, 10) || 25
          };
        }
      }
      Forge.Engine.addCalendarEvent(state, { title: title, date: dateStr, type: typeSelect.value, quest: quest });
      Forge.State.save();
      closeModal();
      render();
    });
  }

  function openEditQuestModal(quest) {
    var state = Forge.State.get();
    var titleLocked = !quest.custom && quest.type !== 'daily';

    function normalizeTimeValue(timeStr) {
      if (!timeStr) return '';
      var ampm = timeStr.match(/(\d{1,2}:\d{2})\s*(AM|PM)/i);
      if (ampm) {
        var parts = ampm[1].split(':');
        var hour = parseInt(parts[0], 10);
        var minute = parts[1];
        if (/pm/i.test(ampm[2]) && hour !== 12) hour += 12;
        if (/am/i.test(ampm[2]) && hour === 12) hour = 0;
        return (hour < 10 ? '0' : '') + hour + ':' + minute;
      }
      var plain = timeStr.match(/(\d{1,2}):(\d{2})/);
      if (plain) return (plain[1].length === 1 ? '0' + plain[1] : plain[1]) + ':' + plain[2];
      return '';
    }

    var html = '<div class="forge-modal-title">Edit Quest</div>';
    html += '<div class="forge-field"><label class="forge-label">Quest Name</label><input class="forge-input" id="eqTitle" maxlength="60" value="' + quest.title.split('"').join('&quot;') + '"' + (titleLocked ? ' disabled' : '') + ' /></div>';
    if (titleLocked) html += '<div style="font-size:11px;color:var(--muted);margin:-8px 0 12px;">Built-in quest names can’t change, but everything else can.</div>';
    html += '<div class="forge-field"><label class="forge-label">Description</label><textarea class="forge-textarea" id="eqFlavor" maxlength="200">' + (quest.flavor || '') + '</textarea></div>';
    html += '<div class="forge-grid-2">';
    html += '  <div class="forge-field"><label class="forge-label">Time (optional)</label><input class="forge-input" id="eqTime" type="time" value="' + normalizeTimeValue(quest.time || '') + '" /></div>';
    html += '  <div class="forge-field"><label class="forge-label">XP Reward</label><input class="forge-input" id="eqXp" type="number" min="1" max="500" value="' + quest.xp + '" /></div>';
    html += '</div>';
    html += '<div class="forge-grid-2" style="margin-top:8px;">';
    html += '  <button class="forge-btn forge-btn-ghost forge-btn-block" data-modal-close="1" style="padding:13px;">Cancel</button>';
    html += '  <button class="forge-btn forge-btn-primary forge-btn-block" id="eqSubmit" style="padding:13px;">Save Changes</button>';
    html += '</div>';

    var el = openModal(html);
    el.querySelector('[data-modal-close]').addEventListener('click', closeModal);
    el.querySelector('#eqSubmit').addEventListener('click', function () {
      var fields = {
        flavor: el.querySelector('#eqFlavor').value.trim(),
        time: el.querySelector('#eqTime').value.trim(),
        xp: parseInt(el.querySelector('#eqXp').value, 10) || quest.xp
      };
      if (!titleLocked) fields.title = el.querySelector('#eqTitle').value.trim();
      if (quest.custom) {
        Forge.Engine.updateCustomQuest(state, quest.id, fields);
      } else {
        Forge.Engine.setQuestOverride(state, quest.templateId, fields);
      }
      Forge.State.save();
      closeModal();
      render();
    });
  }

  // ---------------- cosmetics ----------------
  function applyCosmetics() {
    var state = Forge.State.get();
    rootEl.setAttribute('data-cosmetic', state.crafting.activeTheme || 'forgesteel');

    var cursorOn = !!state.crafting.activeToggles.cursor_ember;
    rootEl.setAttribute('data-cursor', cursorOn ? 'ember' : 'default');
    setupEmberCursor(cursorOn);

    var embersOn = !!state.crafting.activeToggles.bg_embers;
    rootEl.setAttribute('data-embers', embersOn ? '1' : '0');
    if (embersOn) buildEmbers();
  }

  function setupEmberCursor(on) {
    if (on && !cursorEl) {
      cursorEl = document.createElement('div');
      cursorEl.className = 'forge-ember-cursor';
      document.body.appendChild(cursorEl);
      cursorMoveHandler = function (e) {
        cursorEl.style.left = e.clientX + 'px';
        cursorEl.style.top = e.clientY + 'px';
      };
      document.addEventListener('mousemove', cursorMoveHandler);
    } else if (!on && cursorEl) {
      document.removeEventListener('mousemove', cursorMoveHandler);
      cursorEl.remove();
      cursorEl = null;
    }
  }

  function buildEmbers() {
    if (embersBuilt || !embersEl) return;
    embersBuilt = true;
    for (var i = 0; i < 18; i++) {
      var p = document.createElement('div');
      p.className = 'forge-ember-particle';
      p.style.left = Math.round(Math.random() * 100) + '%';
      p.style.setProperty('--drift', (Math.random() * 60 - 30) + 'px');
      p.style.animationDuration = (7 + Math.random() * 8) + 's';
      p.style.animationDelay = (Math.random() * 10) + 's';
      embersEl.appendChild(p);
    }
  }

  return {
    boot: boot,
    restart: afterStateReady,
    render: render,
    toggleQuest: toggleQuest,
    openReportModal: openReportModal,
    openEquipModal: openEquipModal,
    openEventModal: openEventModal,
    openEditQuestModal: openEditQuestModal,
    closeModal: closeModal,
    applyCosmetics: applyCosmetics
  };
})();

document.addEventListener('DOMContentLoaded', function () {
  var appEl = document.getElementById('forgeApp');
  Forge.Auth.onChange(function (user) {
    if (user) {
      Forge.App.boot(user.uid);
    } else {
      appEl.innerHTML = Forge.UI.Login.render();
      Forge.UI.Login.mount(appEl);
    }
  });
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') Forge.State.flush();
  });
});

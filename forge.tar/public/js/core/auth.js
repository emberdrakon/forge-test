// Daily Forge 2.0 — Google sign-in via Firebase Auth
window.Forge = window.Forge || {};

Forge.Auth = (function () {
  function init() {
    // Surfaces redirect-completion errors (e.g. a blocked/cancelled redirect); onChange's
    // own onAuthStateChanged callback is the actual source of truth for signed-in state.
    Forge.Firebase.auth.getRedirectResult().catch(function (e) {
      console.warn('[Forge.Auth] redirect sign-in failed', e);
    });
  }

  function onChange(cb) {
    Forge.Firebase.auth.onAuthStateChanged(cb);
  }

  // Redirect-based (not popup) — popups are unreliable in mobile browsers and are broken
  // outright inside standalone/home-screen PWA contexts, both of which this app targets.
  function signIn() {
    var provider = new firebase.auth.GoogleAuthProvider();
    return Forge.Firebase.auth.signInWithRedirect(provider);
  }

  function signOut() {
    return Forge.Firebase.auth.signOut();
  }

  init();

  return { onChange: onChange, signIn: signIn, signOut: signOut };
})();

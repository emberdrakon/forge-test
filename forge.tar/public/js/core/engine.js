// Daily Forge 2.0 — game rules: xp/levels, quests, loot, crafting, equipment, buffs, bosses, achievements
window.Forge = window.Forge || {};

Forge.Engine = (function () {
  var D = Forge.Data;

  function makeId(prefix) {
    return (prefix || 'id') + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  // ---------------- XP / Level ----------------
  function xpForLevel(n) { return 500 + (n - 1) * 1000; }

  function levelInfo(totalXP) {
    var lvl = 1, remaining = totalXP || 0, need = xpForLevel(1);
    while (remaining >= need) {
      remaining -= need;
      lvl++;
      need = xpForLevel(lvl);
    }
    return { level: lvl, into: remaining, need: need };
  }

  function level(totalXP) { return levelInfo(totalXP).level; }

  var TITLES = [
    { min: 1, max: 4, title: 'Ember Novice' },
    { min: 5, max: 9, title: 'Apprentice Smith' },
    { min: 10, max: 14, title: 'Journeyman' },
    { min: 15, max: 19, title: 'Forge Adept' },
    { min: 20, max: 24, title: 'Steel Warden' },
    { min: 25, max: 29, title: 'Master Smith' },
    { min: 30, max: 39, title: 'Forgebound' },
    { min: 40, max: 49, title: 'Ember Sovereign' },
    { min: 50, max: 9999, title: 'Living Flame' }
  ];

  function titleForLevel(lvl) {
    var t = TITLES.find(function (t) { return lvl >= t.min && lvl <= t.max; });
    return t ? t.title : 'Wanderer';
  }

  function temperColor(pct) {
    if (pct >= 75) return 'var(--accent)';
    if (pct >= 40) return 'var(--gold)';
    return 'var(--steel)';
  }

  // ---------------- day rollover ----------------
  function isWeekday(dateStr) {
    var day = new Date(dateStr + 'T00:00:00').getDay();
    return day >= 1 && day <= 5;
  }

  function applyTemplateFields(state, instance, tpl) {
    instance.title = tpl.title;
    instance.flavor = tpl.flavor;
    instance.time = tpl.time || '';
    instance.section = tpl.section || 'Side';
    instance.area = tpl.area;
    instance.stat = tpl.stat;
    instance.skill = tpl.skill || null;
    instance.xp = tpl.xp;
    instance.type = tpl.type;
    instance.grantsBuff = tpl.grantsBuff || null;
    instance.mealQuest = !!tpl.mealQuest;
    instance.sleepQuest = !!tpl.sleepQuest;
    instance.weekdaysOnly = !!tpl.weekdaysOnly;
    var override = state.questOverrides[tpl.id];
    if (override) {
      if (override.title !== undefined) instance.title = override.title;
      if (override.flavor !== undefined) instance.flavor = override.flavor;
      if (override.time !== undefined) instance.time = override.time;
      if (override.xp !== undefined) instance.xp = override.xp;
    }
  }

  function ensureTodayQuests(state) {
    var today = Forge.State.todayStr();
    var rolledOver = false;
    if (state.today.date !== today) {
      rolloverDay(state, today);
      rolledOver = true;
    }

    // drop instances tied to a template that no longer exists (old content, superseded),
    // or that's restricted to weekdays and today falls on a weekend
    state.quests.instances = state.quests.instances.filter(function (q) {
      if (!q.templateId) return true;
      var tpl = D.QUEST_TEMPLATES.find(function (t) { return t.id === q.templateId; });
      if (!tpl) return false;
      if (tpl.weekdaysOnly && q.date === state.today.date && !isWeekday(state.today.date)) return false;
      return true;
    });

    var existingTemplateIds = {};
    state.quests.instances.forEach(function (q) {
      if (q.templateId && q.date === state.today.date) {
        existingTemplateIds[q.templateId] = true;
        var tpl = D.QUEST_TEMPLATES.find(function (t) { return t.id === q.templateId; });
        if (tpl) applyTemplateFields(state, q, tpl);
      }
    });
    D.QUEST_TEMPLATES.forEach(function (tpl) {
      if (existingTemplateIds[tpl.id]) return;
      if (tpl.weekdaysOnly && !isWeekday(state.today.date)) return;
      var inst = {
        id: makeId('q'),
        templateId: tpl.id,
        done: false,
        date: state.today.date,
        repeat: true,
        custom: false
      };
      applyTemplateFields(state, inst, tpl);
      state.quests.instances.push(inst);
    });

    materializeEventQuests(state);

    // drop stale instances (past days, or one-off customs already resolved)
    state.quests.instances = state.quests.instances.filter(function (q) {
      if (q.date === state.today.date) return true;
      return false;
    });

    return rolledOver;
  }

  // turns an event's tied quest definition into a real, playable quest the day the event arrives
  function materializeEventQuests(state) {
    state.calendar.events.forEach(function (ev) {
      if (ev.date !== state.today.date || !ev.quest || ev.questInstanceId) return;
      var inst = {
        id: makeId('q'),
        templateId: null,
        title: ev.quest.title,
        flavor: ev.quest.flavor || '',
        time: '',
        section: 'Side',
        area: ev.quest.area || 'homeVillage',
        stat: ev.quest.stat || null,
        skill: null,
        xp: Math.max(1, Math.min(500, ev.quest.xp || 25)),
        type: 'side',
        grantsBuff: null,
        mealQuest: false,
        sleepQuest: false,
        done: false,
        date: state.today.date,
        repeat: false,
        custom: true,
        eventId: ev.id
      };
      state.quests.instances.push(inst);
      ev.questInstanceId = inst.id;
    });
  }

  function setQuestOverride(state, templateId, fields) {
    var existing = state.questOverrides[templateId] || {};
    if (fields.title !== undefined && fields.title.trim()) existing.title = fields.title.trim();
    if (fields.flavor !== undefined) existing.flavor = fields.flavor;
    if (fields.time !== undefined) existing.time = fields.time;
    if (fields.xp !== undefined) existing.xp = Math.max(1, Math.min(500, fields.xp));
    state.questOverrides[templateId] = existing;
    var inst = state.quests.instances.find(function (q) { return q.templateId === templateId && q.date === state.today.date; });
    if (inst) {
      if (existing.title !== undefined) inst.title = existing.title;
      if (existing.flavor !== undefined) inst.flavor = existing.flavor;
      if (existing.time !== undefined) inst.time = existing.time;
      if (existing.xp !== undefined) inst.xp = existing.xp;
    }
  }

  function updateCustomQuest(state, questId, fields) {
    var q = state.quests.instances.find(function (x) { return x.id === questId && x.custom; });
    if (!q) return false;
    if (fields.title !== undefined && fields.title.trim()) q.title = fields.title.trim();
    if (fields.flavor !== undefined) q.flavor = fields.flavor;
    if (fields.time !== undefined) q.time = fields.time;
    if (fields.xp !== undefined) q.xp = Math.max(1, Math.min(500, fields.xp));
    return true;
  }

  // any event whose date has passed without its tied quest being completed forfeits its reward
  function resolveExpiredEventQuests(state, todayDate) {
    state.calendar.events.forEach(function (ev) {
      if (!ev.quest || ev.rewardState !== 'pending') return;
      if (ev.date >= todayDate) return;
      ev.rewardState = 'missed';
    });
  }

  function rolloverDay(state, todayDate) {
    var completedAll = dayFullyComplete(state);
    var yesterdayInstances = state.quests.instances.filter(function (q) { return q.date === state.today.date; });
    var meals = yesterdayInstances.filter(function (q) { return q.mealQuest; });
    var sleeps = yesterdayInstances.filter(function (q) { return q.sleepQuest; });
    state.flags.hungryToday = meals.length > 0 && meals.every(function (q) { return !q.done; });
    state.flags.sleepDeprivedToday = sleeps.length > 0 && sleeps.every(function (q) { return !q.done; });
    state.flags.yesterdayTemper = state.character.temper;
    // state.today.date is always populated and, by construction, is the last date
    // this state was current for — use it as the streak reference instead of the
    // separately-tracked meta.lastActiveDate, which starts null and never gets set
    // on the very first day of use (rolloverDay doesn't run that day), silently
    // skipping the streak update for a user's first completed day.
    var lastActive = state.today.date;
    var wasYesterday = isConsecutiveDay(lastActive, todayDate);
    var gapDays = Math.round((new Date(todayDate + 'T00:00:00') - new Date(lastActive + 'T00:00:00')) / 86400000);
    if (wasYesterday && completedAll) {
      state.character.streak = (state.character.streak || 0) + 1;
      state.flags.rustToday = false;
      state.counters.missedDaysStreak = 0;
    } else if (wasYesterday && !completedAll) {
      state.character.streak = 0;
      state.flags.rustToday = true;
      state.counters.missedDaysStreak = (state.counters.missedDaysStreak || 0) + 1;
    } else if (!wasYesterday) {
      state.character.streak = 0;
      state.flags.rustToday = true;
      state.counters.missedDaysStreak = (state.counters.missedDaysStreak || 0) + Math.max(1, gapDays - 1);
    }
    state.counters.maxStreak = Math.max(state.counters.maxStreak || 0, state.character.streak || 0);
    state.flags.gapDays = gapDays;
    state.lastReport = {
      date: state.today.date,
      xpEarned: state.today.xpEarned,
      lootFound: state.today.lootFound,
      statsGained: state.today.statsGained,
      achievementsUnlocked: state.today.achievementsUnlocked,
      streakAtEnd: state.character.streak
    };
    resolveExpiredEventQuests(state, todayDate);

    // one-off custom quests that were completed get cleared; unfinished one-offs carry forward.
    // event-tied quests never carry forward — they live for exactly one day, then the window closes.
    state.quests.instances = state.quests.instances.filter(function (q) {
      if (q.eventId) return false;
      if (q.custom && !q.repeat) return !q.done;
      return true;
    });
    state.quests.instances.forEach(function (q) { q.done = false; q.date = todayDate; });
    state.today = {
      date: todayDate,
      xpEarned: 0,
      lootFound: [],
      statsGained: {},
      achievementsUnlocked: [],
      activeBuffIds: []
    };
    state.character.temper = Math.max(20, Math.round(state.character.temper * 0.35));
    state.meta.lastActiveDate = todayDate;
  }

  function isConsecutiveDay(prev, curr) {
    var p = new Date(prev + 'T00:00:00');
    var c = new Date(curr + 'T00:00:00');
    var diff = Math.round((c - p) / 86400000);
    return diff === 1;
  }

  function dayFullyComplete(state) {
    return state.quests.instances.some(function (q) { return q.done && q.type === 'daily'; });
  }

  function completion(state) {
    var required = state.quests.instances.filter(function (q) { return q.date === state.today.date; });
    if (!required.length) return 0;
    var done = required.filter(function (q) { return q.done; }).length;
    return Math.round((done / required.length) * 100);
  }

  // ---------------- loot ----------------
  function rollLoot(area) {
    var found = [];
    var table = D.DROP_TABLES[area] || [];
    table.concat(D.RARE_GLOBAL_DROPS).forEach(function (drop) {
      if (Math.random() < drop.chance) {
        var qty = drop.min + Math.floor(Math.random() * (drop.max - drop.min + 1));
        found.push({ id: drop.id, qty: qty });
      }
    });
    return found;
  }

  function rollRareEquipment(state) {
    var candidates = D.RARE_EQUIPMENT_DROPS.filter(function (drop) { return state.equipment.owned.indexOf(drop.id) === -1; });
    for (var i = 0; i < candidates.length; i++) {
      if (Math.random() < candidates[i].chance) return candidates[i].id;
    }
    return null;
  }

  // one-time equipment unlock tied to an event type; returns the item id if this grant newly awarded it
  function grantEventEquipment(state, typeInfo) {
    if (!typeInfo.equipment) return null;
    if (state.equipment.owned.indexOf(typeInfo.equipment) !== -1) return null;
    state.equipment.owned.push(typeInfo.equipment);
    return typeInfo.equipment;
  }

  // ---------------- quests ----------------
  function completeQuest(state, questId) {
    var q = state.quests.instances.find(function (x) { return x.id === questId; });
    if (!q || q.done) return null;
    q.done = true;

    var loot = rollLoot(q.area);
    loot.forEach(function (l) { state.inventory.materials[l.id] = (state.inventory.materials[l.id] || 0) + l.qty; });

    if (q.grantsBuff && state.today.activeBuffIds.indexOf(q.grantsBuff) === -1) {
      state.today.activeBuffIds.push(q.grantsBuff);
    }

    var statGain = {};
    if (q.stat) {
      state.character.stats[q.stat] = (state.character.stats[q.stat] || 0) + 1;
      statGain[q.stat] = 1;
    }
    var skillGain = null;
    if (q.skill && state.skills[q.skill]) {
      state.skills[q.skill].xp += Math.round(q.xp * 0.6);
      skillGain = { skill: q.skill, amount: Math.round(q.xp * 0.6) };
    }

    var beforeLevel = level(state.character.totalXP);
    state.character.totalXP += q.xp;
    var afterLevel = level(state.character.totalXP);

    var equipmentFound = rollRareEquipment(state);
    if (equipmentFound) state.equipment.owned.push(equipmentFound);

    var eventReward = null;
    if (q.eventId) {
      var ev = state.calendar.events.find(function (e) { return e.id === q.eventId; });
      if (ev && ev.rewardState === 'pending') {
        var typeInfo = D.getEventType(ev.type);
        var eventGranted = {};
        Object.keys(typeInfo.materials).forEach(function (matId) {
          var qty = typeInfo.materials[matId];
          state.inventory.materials[matId] = (state.inventory.materials[matId] || 0) + qty;
          eventGranted[matId] = qty;
        });
        if (state.today.activeBuffIds.indexOf(typeInfo.buff) === -1) state.today.activeBuffIds.push(typeInfo.buff);
        var eventEquipment = grantEventEquipment(state, typeInfo);
        ev.rewardState = 'granted';
        eventReward = { event: ev, typeInfo: typeInfo, granted: eventGranted, equipment: eventEquipment };
      }
    }

    q.grantedLoot = loot;
    q.grantedStat = statGain;
    q.grantedSkill = skillGain;
    q.grantedXp = q.xp;
    q.grantedEquipment = equipmentFound;
    q.grantedEventReward = eventReward;

    state.position.areaId = q.area;
    state.counters.areasVisited[q.area] = true;
    state.counters.questsCompleted += 1;
    if (q.area === 'corporateDungeon') state.counters.dungeonQuests += 1;
    var hour = new Date().getHours();
    if (hour < 8) state.counters.earlyBirdCount += 1;
    if (hour >= 22) state.counters.nightOwlCount += 1;

    state.today.xpEarned += q.xp;
    loot.forEach(function (l) {
      var existing = state.today.lootFound.find(function (x) { return x.id === l.id; });
      if (existing) existing.qty += l.qty; else state.today.lootFound.push({ id: l.id, qty: l.qty });
    });
    Object.keys(statGain).forEach(function (k) { state.today.statsGained[k] = (state.today.statsGained[k] || 0) + statGain[k]; });

    var temperStep = q.type === 'side' ? 4 : 7;
    state.character.temper = Math.min(100, state.character.temper + temperStep);
    state.counters.maxTemper = Math.max(state.counters.maxTemper || 0, state.character.temper);

    var newAch = checkAchievements(state);

    return {
      xpGained: q.xp,
      loot: loot,
      equipmentFound: equipmentFound,
      eventReward: eventReward,
      statGain: statGain,
      skillGain: skillGain,
      leveledUp: afterLevel > beforeLevel,
      newLevel: afterLevel,
      newAchievements: newAch
    };
  }

  function uncompleteQuest(state, questId) {
    var q = state.quests.instances.find(function (x) { return x.id === questId; });
    if (!q || !q.done) return;
    q.done = false;
    state.character.totalXP = Math.max(0, state.character.totalXP - (q.grantedXp || 0));
    state.today.xpEarned = Math.max(0, state.today.xpEarned - (q.grantedXp || 0));
    if (q.grantedEquipment) {
      state.equipment.owned = state.equipment.owned.filter(function (id) { return id !== q.grantedEquipment; });
      Object.keys(state.equipment.slots).forEach(function (slot) {
        if (state.equipment.slots[slot] === q.grantedEquipment) state.equipment.slots[slot] = null;
      });
    }
    if (q.grantsBuff) {
      state.today.activeBuffIds = state.today.activeBuffIds.filter(function (id) { return id !== q.grantsBuff; });
    }
    if (q.grantedEventReward) {
      Object.keys(q.grantedEventReward.granted).forEach(function (matId) {
        state.inventory.materials[matId] = Math.max(0, (state.inventory.materials[matId] || 0) - q.grantedEventReward.granted[matId]);
      });
      if (q.grantedEventReward.equipment) {
        state.equipment.owned = state.equipment.owned.filter(function (id) { return id !== q.grantedEventReward.equipment; });
        Object.keys(state.equipment.slots).forEach(function (slot) {
          if (state.equipment.slots[slot] === q.grantedEventReward.equipment) state.equipment.slots[slot] = null;
        });
      }
      state.today.activeBuffIds = state.today.activeBuffIds.filter(function (id) { return id !== q.grantedEventReward.typeInfo.buff; });
      var linkedEvent = state.calendar.events.find(function (e) { return e.id === q.eventId; });
      if (linkedEvent) linkedEvent.rewardState = 'pending';
    }
    if (q.grantedStat) {
      Object.keys(q.grantedStat).forEach(function (stat) {
        state.character.stats[stat] = Math.max(0, state.character.stats[stat] - q.grantedStat[stat]);
        state.today.statsGained[stat] = Math.max(0, (state.today.statsGained[stat] || 0) - q.grantedStat[stat]);
      });
    }
    if (q.grantedSkill && state.skills[q.grantedSkill.skill]) {
      state.skills[q.grantedSkill.skill].xp = Math.max(0, state.skills[q.grantedSkill.skill].xp - q.grantedSkill.amount);
    }
    if (q.grantedLoot) {
      q.grantedLoot.forEach(function (l) {
        state.inventory.materials[l.id] = Math.max(0, (state.inventory.materials[l.id] || 0) - l.qty);
        var t = state.today.lootFound.find(function (x) { return x.id === l.id; });
        if (t) t.qty = Math.max(0, t.qty - l.qty);
      });
    }
    state.counters.questsCompleted = Math.max(0, state.counters.questsCompleted - 1);
    state.character.temper = Math.max(0, state.character.temper - (q.type === 'side' ? 4 : 7));
    q.grantedLoot = null; q.grantedStat = null; q.grantedSkill = null; q.grantedXp = 0; q.grantedEquipment = null; q.grantedEventReward = null;
  }

  function addCustomQuest(state, opts) {
    var inst = {
      id: makeId('q'),
      templateId: null,
      title: opts.title,
      flavor: opts.flavor || '',
      time: opts.time || '',
      section: 'Custom',
      area: opts.area || 'homeVillage',
      stat: opts.stat || null,
      skill: null,
      xp: Math.max(1, Math.min(500, opts.xp || 15)),
      type: 'side',
      grantsBuff: null,
      mealQuest: false,
      sleepQuest: false,
      done: false,
      date: state.today.date,
      repeat: !!opts.repeat,
      custom: true
    };
    state.quests.instances.push(inst);
    return inst;
  }

  function removeCustomQuest(state, questId) {
    state.quests.instances = state.quests.instances.filter(function (q) { return q.id !== questId; });
  }

  // ---------------- buffs / debuffs (computed, not persisted beyond activeBuffIds) ----------------
  function computeStatus(state) {
    var buffs = [], debuffs = [];
    var doneToday = state.quests.instances.filter(function (q) { return q.date === state.today.date && q.done; });
    var hour = new Date().getHours();

    if (state.flags.yesterdayTemper >= 80) buffs.push(D.BUFFS.well_rested);
    if (doneToday.some(function (q) { return q.stat === 'vitality'; })) buffs.push(D.BUFFS.hydrated);
    if (doneToday.some(function (q) { return q.stat === 'strength'; })) buffs.push(D.BUFFS.runners_high);
    if (doneToday.some(function (q) { return q.stat === 'creativity'; })) buffs.push(D.BUFFS.inspired);
    if (doneToday.some(function (q) { return q.stat === 'knowledge'; }) || state.today.activeBuffIds.indexOf('focused') !== -1) buffs.push(D.BUFFS.focused);
    if (state.today.activeBuffIds.indexOf('well_rested') !== -1 && buffs.indexOf(D.BUFFS.well_rested) === -1) buffs.push(D.BUFFS.well_rested);
    if ((state.character.streak || 0) >= 5) buffs.push(D.BUFFS.on_a_roll);

    var mealDoneToday = doneToday.some(function (q) { return q.mealQuest; });
    if (state.flags.rustToday && doneToday.length === 0) debuffs.push(D.DEBUFFS.rust);
    if (state.flags.hungryToday && !mealDoneToday) debuffs.push(D.DEBUFFS.hungry);
    if (state.counters.missedDaysStreak >= 3) debuffs.push(D.DEBUFFS.burnout);
    if ((state.flags.sleepDeprivedToday && doneToday.length === 0) || (hour >= 23 && doneToday.length === 0)) debuffs.push(D.DEBUFFS.sleep_deprived);
    if (state.character.temper < 30 && completion(state) < 100) debuffs.push(D.DEBUFFS.distracted);

    return { buffs: uniqueBy(buffs, 'name'), debuffs: uniqueBy(debuffs, 'name') };
  }

  function uniqueBy(arr, key) {
    var seen = {};
    return arr.filter(function (x) { if (seen[x[key]]) return false; seen[x[key]] = true; return true; });
  }

  function applyConsumable(state, itemId) {
    var item = D.getItem(itemId);
    if (!item || (state.inventory.consumables[itemId] || 0) <= 0) return false;
    state.inventory.consumables[itemId] -= 1;
    if (item.effect === 'temper') {
      state.character.temper = Math.min(100, state.character.temper + item.amount);
    } else if (item.effect === 'buff' && state.today.activeBuffIds.indexOf(item.buffId) === -1) {
      state.today.activeBuffIds.push(item.buffId);
    }
    return true;
  }

  // ---------------- crafting / equipment ----------------
  function canAfford(state, cost) {
    return Object.keys(cost).every(function (id) { return (state.inventory.materials[id] || 0) >= cost[id]; });
  }

  function craftRecipe(state, recipeId) {
    var recipe = D.RECIPES.find(function (r) { return r.id === recipeId; });
    if (!recipe) return { ok: false, reason: 'unknown-recipe' };
    if (recipe.cosmeticId && state.crafting.unlockedCosmetics.indexOf(recipe.cosmeticId) !== -1) return { ok: false, reason: 'already-unlocked' };
    if (recipe.itemId && state.equipment.owned.indexOf(recipe.itemId) !== -1) return { ok: false, reason: 'already-owned' };
    if (!canAfford(state, recipe.cost)) return { ok: false, reason: 'insufficient-materials' };
    Object.keys(recipe.cost).forEach(function (id) { state.inventory.materials[id] -= recipe.cost[id]; });
    if (recipe.cosmeticId) state.crafting.unlockedCosmetics.push(recipe.cosmeticId);
    if (recipe.itemId) state.equipment.owned.push(recipe.itemId);
    state.counters.craftsMade += 1;
    var newAch = checkAchievements(state);
    return { ok: true, recipe: recipe, newAchievements: newAch };
  }

  function equipItem(state, itemId) {
    var item = D.getItem(itemId);
    if (!item || item.kind !== 'equipment') return false;
    if (state.equipment.owned.indexOf(itemId) === -1) return false;
    state.equipment.slots[item.slot] = itemId;
    checkAchievements(state);
    return true;
  }

  function unequipItem(state, slot) {
    state.equipment.slots[slot] = null;
  }

  function statBonusFromEquipment(state, stat) {
    var total = 0;
    Object.values(state.equipment.slots).forEach(function (itemId) {
      if (!itemId) return;
      var item = D.getItem(itemId);
      if (item && item.bonus && item.bonus.stat === stat) total += item.bonus.amount;
    });
    return total;
  }

  function setActiveTheme(state, cosmeticId) {
    if (state.crafting.unlockedCosmetics.indexOf(cosmeticId) === -1) return false;
    state.crafting.activeTheme = cosmeticId;
    return true;
  }

  function toggleCosmetic(state, cosmeticId) {
    if (state.crafting.unlockedCosmetics.indexOf(cosmeticId) === -1) return false;
    state.crafting.activeToggles[cosmeticId] = !state.crafting.activeToggles[cosmeticId];
    return true;
  }

  // ---------------- bosses ----------------
  function addBoss(state, opts) {
    var boss = {
      id: makeId('boss'),
      name: opts.name,
      date: opts.date,
      difficulty: Math.max(1, Math.min(5, opts.difficulty || 3)),
      recommendedLevel: Math.max(1, opts.recommendedLevel || 1),
      prep: 0,
      notes: opts.notes || '',
      cleared: false
    };
    state.bosses.push(boss);
    return boss;
  }

  function removeBoss(state, id) {
    state.bosses = state.bosses.filter(function (b) { return b.id !== id; });
  }

  function logBossPrep(state, id, amount) {
    var boss = state.bosses.find(function (b) { return b.id === id; });
    if (!boss) return;
    boss.prep = Math.max(0, Math.min(100, boss.prep + (amount || 5)));
  }

  // guaranteed part of a boss's reward; clearBoss additionally rolls a chance at rare materials on top
  function bossRewardPreview(difficulty) {
    return {
      xp: 50 + difficulty * 25,
      materials: { crystal: difficulty, ember_dust: difficulty }
    };
  }

  function clearBoss(state, id) {
    var boss = state.bosses.find(function (b) { return b.id === id; });
    if (!boss || boss.cleared) return null;
    boss.cleared = true;
    state.counters.bossesCleared += 1;

    var preview = bossRewardPreview(boss.difficulty);
    var granted = Object.assign({}, preview.materials);
    var rareChance = boss.difficulty * 0.15;
    if (Math.random() < rareChance) {
      var rareId = boss.difficulty >= 4 ? 'phoenix_feather' : 'obsidian_shard';
      granted[rareId] = (granted[rareId] || 0) + 1;
    }
    Object.keys(granted).forEach(function (matId) {
      state.inventory.materials[matId] = (state.inventory.materials[matId] || 0) + granted[matId];
    });

    var beforeLevel = level(state.character.totalXP);
    state.character.totalXP += preview.xp;
    var afterLevel = level(state.character.totalXP);

    if (state.today.activeBuffIds.indexOf('on_a_roll') === -1) state.today.activeBuffIds.push('on_a_roll');

    state.today.xpEarned += preview.xp;
    Object.keys(granted).forEach(function (matId) {
      var existing = state.today.lootFound.find(function (x) { return x.id === matId; });
      if (existing) existing.qty += granted[matId]; else state.today.lootFound.push({ id: matId, qty: granted[matId] });
    });

    var newAch = checkAchievements(state);
    return {
      xpGained: preview.xp,
      granted: granted,
      leveledUp: afterLevel > beforeLevel,
      newLevel: afterLevel,
      newAchievements: newAch
    };
  }

  function bossSuccessChance(state, boss) {
    var playerLevel = level(state.character.totalXP);
    var chance = 50 + (playerLevel - boss.recommendedLevel) * 4 + boss.prep * 0.4 - boss.difficulty * 8;
    return Math.max(5, Math.min(97, Math.round(chance)));
  }

  // ---------------- calendar ----------------
  // opts.quest, if provided ({title, flavor, area, stat, xp}), gates the reward behind completing
  // that one-time quest on the event's day. Without it, the reward is granted automatically.
  function addCalendarEvent(state, opts) {
    var typeInfo = D.getEventType(opts.type);
    var ev = {
      id: makeId('ev'),
      title: opts.title,
      date: opts.date,
      type: typeInfo.id,
      icon: typeInfo.icon,
      quest: opts.quest || null,
      questInstanceId: null,
      rewardState: 'pending'
    };
    state.calendar.events.push(ev);
    state.calendar.events.sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    return ev;
  }

  function removeCalendarEvent(state, id) {
    state.calendar.events = state.calendar.events.filter(function (e) { return e.id !== id; });
    state.quests.instances = state.quests.instances.filter(function (q) { return q.eventId !== id; });
  }

  function nextUpcomingEvent(state) {
    var today = Forge.State.todayStr();
    var future = state.calendar.events.filter(function (e) { return e.date >= today; });
    if (!future.length) return null;
    future.sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    var ev = future[0];
    var days = Math.round((new Date(ev.date + 'T00:00:00') - new Date(today + 'T00:00:00')) / 86400000);
    if (days > 14) return null;
    return { event: ev, daysAway: days, typeInfo: D.getEventType(ev.type) };
  }

  // grants the reward for events with no tied quest, the day they arrive.
  // events WITH a tied quest are instead paid out from completeQuest() when that quest is done.
  function checkSeasonalEvents(state) {
    var today = Forge.State.todayStr();
    var rewards = [];
    state.calendar.events.forEach(function (ev) {
      if (ev.date !== today) return;
      if (ev.quest) return;
      if (ev.rewardState !== 'pending') return;
      var typeInfo = D.getEventType(ev.type);
      var granted = {};
      Object.keys(typeInfo.materials).forEach(function (matId) {
        var qty = typeInfo.materials[matId];
        state.inventory.materials[matId] = (state.inventory.materials[matId] || 0) + qty;
        granted[matId] = qty;
      });
      if (state.today.activeBuffIds.indexOf(typeInfo.buff) === -1) state.today.activeBuffIds.push(typeInfo.buff);
      var equipment = grantEventEquipment(state, typeInfo);
      ev.rewardState = 'granted';
      rewards.push({ event: ev, typeInfo: typeInfo, granted: granted, equipment: equipment });
    });
    return rewards;
  }

  // ---------------- achievements ----------------
  function checkAchievements(state) {
    var unlocked = [];
    D.ACHIEVEMENTS.forEach(function (a) {
      if (state.achievements.unlocked[a.id]) return;
      var progress = a.getProgress(state);
      if (progress >= a.target) {
        state.achievements.unlocked[a.id] = Forge.State.todayStr();
        state.today.achievementsUnlocked.push(a.id);
        unlocked.push(a);
      }
    });
    return unlocked;
  }

  // ---------------- forge log ----------------
  function addLogEntry(state, title, text) {
    var trimmed = (text || '').trim();
    if (!trimmed) return null;
    var entry = {
      id: makeId('log'),
      title: (title || '').trim(),
      text: trimmed,
      createdAt: new Date().toISOString(),
      date: state.today.date
    };
    state.logs.unshift(entry);
    return entry;
  }

  function removeLogEntry(state, entryId) {
    state.logs = state.logs.filter(function (e) { return e.id !== entryId; });
  }

  // ---------------- world ----------------
  function unlockedAreas(state) {
    var lvl = level(state.character.totalXP);
    return D.AREAS.filter(function (a) { return lvl >= a.unlockLevel; }).map(function (a) { return a.id; });
  }

  function visitArea(state, areaId) {
    state.counters.areasVisited[areaId] = true;
    checkAchievements(state);
  }

  return {
    makeId: makeId,
    levelInfo: levelInfo,
    level: level,
    titleForLevel: titleForLevel,
    temperColor: temperColor,
    ensureTodayQuests: ensureTodayQuests,
    dayFullyComplete: dayFullyComplete,
    completion: completion,
    completeQuest: completeQuest,
    uncompleteQuest: uncompleteQuest,
    addCustomQuest: addCustomQuest,
    removeCustomQuest: removeCustomQuest,
    setQuestOverride: setQuestOverride,
    updateCustomQuest: updateCustomQuest,
    computeStatus: computeStatus,
    applyConsumable: applyConsumable,
    craftRecipe: craftRecipe,
    equipItem: equipItem,
    unequipItem: unequipItem,
    statBonusFromEquipment: statBonusFromEquipment,
    setActiveTheme: setActiveTheme,
    toggleCosmetic: toggleCosmetic,
    addBoss: addBoss,
    removeBoss: removeBoss,
    logBossPrep: logBossPrep,
    clearBoss: clearBoss,
    bossRewardPreview: bossRewardPreview,
    bossSuccessChance: bossSuccessChance,
    addCalendarEvent: addCalendarEvent,
    removeCalendarEvent: removeCalendarEvent,
    nextUpcomingEvent: nextUpcomingEvent,
    checkSeasonalEvents: checkSeasonalEvents,
    checkAchievements: checkAchievements,
    unlockedAreas: unlockedAreas,
    visitArea: visitArea,
    addLogEntry: addLogEntry,
    removeLogEntry: removeLogEntry
  };
})();

// Daily Forge 2.0 — hand-built inline SVG icon set (no external image assets)
window.Forge = window.Forge || {};

Forge.Icons = (function () {
  var LINE = 'fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"';

  var paths = {
    // materials / loot
    ore: '<polygon points="12,2.5 20,7.5 20,16.5 12,21.5 4,16.5 4,7.5" ' + LINE + '/><path d="M4 7.5 12 12 20 7.5M12 12v9.5" ' + LINE + '/>',
    coal: '<rect x="4" y="7" width="16" height="12" rx="2" ' + LINE + '/><path d="M8 11h3M13 11h3M8 15h8" ' + LINE + '/>',
    leather: '<path d="M12 2c4 2 8 2 8 6 0 8-4 12-8 14-4-2-8-6-8-14 0-4 4-4 8-6z" ' + LINE + '/><path d="M12 6v13" ' + LINE + '/>',
    page: '<path d="M6 3h9l3 3v15H6z" ' + LINE + '/><path d="M15 3v3h3M9 11h6M9 15h6M9 7h2" ' + LINE + '/>',
    scroll: '<path d="M6 5c0-1.5 1-2 2-2s2 .5 2 2v14c0 1.5-1 2-2 2s-2-.5-2-2M8 5h10c1.5 0 2 1 2 2s-.5 2-2 2H10M8 19h10c1.5 0 2-1 2-2" ' + LINE + '/>',
    herb: '<path d="M12 21c0-7 0-11 0-16M12 10c0-4-3-6-6-6 0 4 2 7 6 6zM12 14c0-4 3-6 6-6 0 4-2 7-6 6z" ' + LINE + '/>',
    crystal: '<polygon points="12,2 18,9 12,22 6,9" ' + LINE + '/><path d="M6 9h12M9 9l3-7 3 7" ' + LINE + '/>',
    feather: '<path d="M20 4c-8 0-16 6-16 16 3-1 6-2 8-4M20 4c0 8-6 13-11 15M13 15l6-6M9 19l4-4" ' + LINE + '/>',
    shard: '<polygon points="12,2 16,10 12,22 8,10" ' + LINE + '/>',
    dust: '<circle cx="7" cy="8" r="1.3" fill="currentColor"/><circle cx="13" cy="5" r="1" fill="currentColor"/><circle cx="17" cy="12" r="1.5" fill="currentColor"/><circle cx="9" cy="16" r="1" fill="currentColor"/><circle cx="15" cy="18" r="1.3" fill="currentColor"/>',
    potion: '<path d="M10 2h4M10 2v5l-4 9c-1 2 .5 5 3 5h6c2.5 0 4-3 3-5l-4-9V2" ' + LINE + '/><path d="M8 15h8" ' + LINE + '/>',

    // equipment
    helmet: '<path d="M4 15c0-6 3.5-10 8-10s8 4 8 10" ' + LINE + '/><path d="M4 15h16v2c0 1-1 2-2 2h-1v-3M8 19v-3M7 15c0-3 2-5 5-5s5 2 5 5" ' + LINE + '/>',
    armor: '<path d="M12 2 5 5v6c0 6 3 9.5 7 11 4-1.5 7-5 7-11V5z" ' + LINE + '/><path d="M12 2v20M8 9h8" ' + LINE + '/>',
    accessory: '<circle cx="12" cy="9" r="5" ' + LINE + '/><path d="M9 13.5 7 22h10l-2-8.5" ' + LINE + '/><circle cx="12" cy="9" r="2" ' + LINE + '/>',
    pet: '<circle cx="6.5" cy="7.5" r="1.6" ' + LINE + '/><circle cx="11" cy="5.5" r="1.6" ' + LINE + '/><circle cx="15.5" cy="5.5" r="1.6" ' + LINE + '/><circle cx="18.5" cy="8.5" r="1.6" ' + LINE + '/><path d="M12 10c-4 0-7 2.5-7 6 0 3 2.5 5 7 5s7-2 7-5c0-3.5-3-6-7-6z" ' + LINE + '/>',
    tool: '<path d="M14.5 6.5 18 3l3 3-3.5 3.5M14.5 6.5 5 16v3h3l9.5-9.5M14.5 6.5l3 3" ' + LINE + '/>',
    sword: '<path d="M6 18 17 7M17 7h3V4h-3zM6 18l-2 2M9 15l2 2M6 18l3-3" ' + LINE + '/>',
    shield: '<path d="M12 3l7 3v6c0 5-3 8-7 9-4-1-7-4-7-9V6z" ' + LINE + '/><path d="M9 12l2 2 4-4" ' + LINE + '/>',

    // ui / nav
    home: '<path d="M4 11 12 4l8 7" ' + LINE + '/><path d="M6 10v9h5v-5h2v5h5v-9" ' + LINE + '/>',
    character: '<circle cx="12" cy="8" r="4" ' + LINE + '/><path d="M4 21c0-4.5 3.5-7 8-7s8 2.5 8 7" ' + LINE + '/>',
    world: '<circle cx="12" cy="12" r="9" ' + LINE + '/><path d="M3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18" ' + LINE + '/>',
    quests: '<path d="M6 3h12v18l-6-3-6 3z" ' + LINE + '/><path d="M9 8h6M9 12h6" ' + LINE + '/>',
    bag: '<path d="M6 8h12l1 12H5z" ' + LINE + '/><path d="M9 8V6a3 3 0 016 0v2" ' + LINE + '/>',
    craft: '<path d="M17 3l4 4-2.5 2.5-4-4zM14.5 5.5 4 16v3.5h3.5L18 9" ' + LINE + '/>',
    skills: '<path d="M12 2v6M12 16v6M2 12h6M16 12h6" ' + LINE + '/><circle cx="12" cy="12" r="4" ' + LINE + '/>',
    boss: '<path d="M4 10c0-5 3.5-7 8-7s8 2 8 7-3 8-8 8-8-3-8-8z" ' + LINE + '/><circle cx="9" cy="10" r="1" fill="currentColor"/><circle cx="15" cy="10" r="1" fill="currentColor"/><path d="M9 15c1.5 1 4.5 1 6 0M6 6l-2-3M18 6l2-3" ' + LINE + '/>',
    trophy: '<path d="M7 4h10v5c0 3-2 5-5 5s-5-2-5-5z" ' + LINE + '/><path d="M7 5H4v2c0 2 1.5 3 3 3M17 5h3v2c0 2-1.5 3-3 3M9 19h6M12 14v5" ' + LINE + '/>',
    calendar: '<rect x="3.5" y="5" width="17" height="16" rx="2" ' + LINE + '/><path d="M3.5 9.5h17M8 3v4M16 3v4" ' + LINE + '/>',
    settings: '<circle cx="12" cy="12" r="3" ' + LINE + '/><path d="M19.4 13.5a1.7 1.7 0 000-3l1.3-1.4-2-3.4-1.8.7a1.7 1.7 0 00-2.6-1.5L14 3h-4l-.3 1.9a1.7 1.7 0 00-2.6 1.5l-1.8-.7-2 3.4L4.6 10.5a1.7 1.7 0 000 3L3.3 15l2 3.4 1.8-.7a1.7 1.7 0 002.6 1.5L10 21h4l.3-1.9a1.7 1.7 0 002.6-1.5l1.8.7 2-3.4z" ' + LINE + '/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16" ' + LINE + '/>',
    close: '<path d="M5 5l14 14M19 5L5 19" ' + LINE + '/>',
    check: '<path d="M4 12l5 5L20 6" ' + LINE + '/>',
    chevron: '<path d="M9 6l6 6-6 6" ' + LINE + '/>',
    plus: '<path d="M12 5v14M5 12h14" ' + LINE + '/>',
    flame: '<path d="M12 22c4 0 7-2.8 7-7 0-3-1.5-4.8-2.5-6.5-.3 2-1.2 3-2 3 .5-3-.5-6-3.5-8.5.3 3-1 4.8-3 7C6 12 5 13.8 5 15c0 4.2 3 7 7 7z" fill="currentColor"/>',
    footprint: '<ellipse cx="12" cy="9" rx="4" ry="5" fill="currentColor"/><ellipse cx="12" cy="18" rx="3" ry="4" fill="currentColor" opacity="0.6"/>',
    star: '<polygon points="12,2.5 15,9 22,9.7 16.7,14.3 18.3,21.2 12,17.4 5.7,21.2 7.3,14.3 2,9.7 9,9" ' + LINE + '/>',
    book: '<path d="M4 5c2-1 5-1 8 0v14c-3-1-6-1-8 0zM20 5c-2-1-5-1-8 0v14c3-1 6-1 8 0z" ' + LINE + '/>',
    map: '<path d="M9 4 4 6v14l5-2 6 2 5-2V4l-5 2-6-2z" ' + LINE + '/><path d="M9 4v14M15 6v14" ' + LINE + '/>',
    sound: '<path d="M4 10v4h4l5 4V6l-5 4z" ' + LINE + '/><path d="M17 9c1.2 1 1.2 5 0 6M19.5 6.5c2.5 2.5 2.5 8.5 0 11" ' + LINE + '/>',
    mute: '<path d="M4 10v4h4l5 4V6l-5 4z" ' + LINE + '/><path d="M17 9l4 6M21 9l-4 6" ' + LINE + '/>',
    export: '<path d="M12 3v12M7 8l5-5 5 5" ' + LINE + '/><path d="M4 16v3a2 2 0 002 2h12a2 2 0 002-2v-3" ' + LINE + '/>',
    import: '<path d="M12 15V3M7 10l5 5 5-5" ' + LINE + '/><path d="M4 16v3a2 2 0 002 2h12a2 2 0 002-2v-3" ' + LINE + '/>',
    reset: '<path d="M4 4v6h6" ' + LINE + '/><path d="M5 13a8 8 0 1 0 2.3-6.7L4 10" ' + LINE + '/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2" ' + LINE + '/><path d="M8 11V7a4 4 0 018 0v4" ' + LINE + '/>',
    edit: '<path d="M4 20l1-4 11-11 3 3-11 11z" ' + LINE + '/><path d="M14 6l3 3" ' + LINE + '/>',
    signout: '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" ' + LINE + '/><path d="M16 17l5-5-5-5M21 12H9" ' + LINE + '/>'
  };

  function svg(name, cls) {
    var body = paths[name] || paths.star;
    return '<svg viewBox="0 0 24 24" class="' + (cls || '') + '">' + body + '</svg>';
  }

  return { svg: svg, has: function (name) { return !!paths[name]; } };
})();

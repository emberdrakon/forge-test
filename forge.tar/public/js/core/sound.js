// Daily Forge 2.0 — procedural sound effects via WebAudio (no external audio files)
window.Forge = window.Forge || {};

Forge.Sound = (function () {
  var ctx = null;
  var enabled = true;

  function getCtx() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function setEnabled(v) { enabled = v; }
  function isEnabled() { return enabled; }

  function tone(freq, start, dur, type, gainPeak) {
    var c = getCtx();
    if (!c) return;
    var osc = c.createOscillator();
    var gain = c.createGain();
    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(freq, c.currentTime + start);
    gain.gain.setValueAtTime(0, c.currentTime + start);
    gain.gain.linearRampToValueAtTime(gainPeak || 0.15, c.currentTime + start + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + start + dur);
    osc.connect(gain);
    gain.connect(c.destination);
    osc.start(c.currentTime + start);
    osc.stop(c.currentTime + start + dur + 0.02);
  }

  function noiseBurst(start, dur, gainPeak) {
    var c = getCtx();
    if (!c) return;
    var bufferSize = Math.floor(c.sampleRate * dur);
    var buffer = c.createBuffer(1, bufferSize, c.sampleRate);
    var data = buffer.getChannelData(0);
    for (var i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    }
    var src = c.createBufferSource();
    src.buffer = buffer;
    var filter = c.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1200;
    var gain = c.createGain();
    gain.gain.setValueAtTime(gainPeak || 0.2, c.currentTime + start);
    gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + start + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(c.destination);
    src.start(c.currentTime + start);
  }

  function play(name) {
    if (!enabled) return;
    try {
      switch (name) {
        case 'hammer':
          noiseBurst(0, 0.09, 0.35);
          tone(120, 0, 0.12, 'triangle', 0.2);
          break;
        case 'questComplete':
          tone(392, 0, 0.12, 'triangle', 0.16);
          tone(523.25, 0.09, 0.16, 'triangle', 0.16);
          tone(659.25, 0.18, 0.22, 'triangle', 0.15);
          break;
        case 'loot':
          tone(700, 0, 0.06, 'sine', 0.12);
          tone(1000, 0.05, 0.09, 'sine', 0.12);
          break;
        case 'achievement':
          tone(440, 0, 0.14, 'sawtooth', 0.1);
          tone(554.37, 0.1, 0.14, 'sawtooth', 0.1);
          tone(659.25, 0.2, 0.3, 'sawtooth', 0.12);
          break;
        case 'levelUp':
          tone(261.6, 0, 0.15, 'triangle', 0.14);
          tone(329.6, 0.12, 0.15, 'triangle', 0.14);
          tone(392, 0.24, 0.15, 'triangle', 0.14);
          tone(523.2, 0.36, 0.35, 'triangle', 0.16);
          break;
        case 'craft':
          noiseBurst(0, 0.08, 0.3);
          tone(140, 0, 0.1, 'triangle', 0.18);
          noiseBurst(0.16, 0.08, 0.3);
          tone(140, 0.16, 0.1, 'triangle', 0.18);
          noiseBurst(0.32, 0.08, 0.32);
          tone(165, 0.32, 0.14, 'triangle', 0.2);
          tone(523.25, 0.46, 0.3, 'sine', 0.13);
          break;
        case 'error':
          tone(160, 0, 0.18, 'square', 0.1);
          break;
        case 'click':
          tone(600, 0, 0.04, 'sine', 0.05);
          break;
        default:
          break;
      }
    } catch (e) { /* audio unavailable — silently ignore */ }
  }

  return { play: play, setEnabled: setEnabled, isEnabled: isEnabled };
})();

// Daily Forge 2.0 — live game state: defaults, load/save
window.Forge = window.Forge || {};

Forge.State = (function () {
  var state = null;
  var uid = null;

  function todayStr() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  function zeroMap(list) {
    var m = {};
    list.forEach(function (item) { m[item.id] = 0; });
    return m;
  }

  function defaultState() {
    return {
      version: 2,
      character: {
        name: 'Wanderer',
        className: 'Wanderer',
        totalXP: 0,
        stats: { strength: 0, knowledge: 0, discipline: 0, vitality: 0, creativity: 0, social: 0 },
        streak: 0,
        temper: 0
      },
      position: { areaId: 'homeVillage' },
      today: {
        date: todayStr(),
        xpEarned: 0,
        lootFound: [],
        statsGained: {},
        achievementsUnlocked: [],
        activeBuffIds: []
      },
      flags: {
        rustToday: false,
        hungryToday: false,
        sleepDeprivedToday: false,
        yesterdayTemper: 0,
        gapDays: 0
      },
      quests: { instances: [] },
      questOverrides: {},
      inventory: {
        materials: zeroMap(Forge.Data.MATERIALS),
        consumables: zeroMap(Forge.Data.CONSUMABLES),
        questItems: {}
      },
      equipment: {
        slots: { helmet: null, armor: null, accessory: null, pet: null, tool: null },
        owned: []
      },
      crafting: {
        unlockedCosmetics: ['forgesteel'],
        activeTheme: 'forgesteel',
        activeToggles: {}
      },
      skills: (function () {
        var m = {};
        Forge.Data.SKILLS.forEach(function (s) { m[s.id] = { xp: 0 }; });
        return m;
      })(),
      bosses: [],
      calendar: { events: [] },
      logs: [],
      achievements: { unlocked: {} },
      counters: {
        questsCompleted: 0,
        earlyBirdCount: 0,
        nightOwlCount: 0,
        craftsMade: 0,
        dungeonQuests: 0,
        areasVisited: {},
        maxStreak: 0,
        maxTemper: 0,
        bossesCleared: 0,
        missedDaysStreak: 0
      },
      settings: { soundOn: true },
      lastReport: null,
      meta: { lastActiveDate: null, createdAt: todayStr() }
    };
  }

  function migrate(loaded) {
    var fresh = defaultState();
    function deepFill(target, source) {
      Object.keys(source).forEach(function (k) {
        if (target[k] === undefined) { target[k] = source[k]; }
        else if (typeof source[k] === 'object' && source[k] !== null && !Array.isArray(source[k]) &&
                 typeof target[k] === 'object' && target[k] !== null && !Array.isArray(target[k])) {
          deepFill(target[k], source[k]);
        }
      });
      return target;
    }
    var merged = deepFill(loaded, fresh);
    // older saves tracked a claimed-date map instead of a rewardState per event
    if (merged.calendar && Array.isArray(merged.calendar.events)) {
      merged.calendar.events.forEach(function (ev) {
        if (ev.rewardState === undefined) {
          ev.rewardState = (merged.calendar.claimed && merged.calendar.claimed[ev.id]) ? 'granted' : 'pending';
        }
        if (ev.quest === undefined) ev.quest = null;
        if (ev.questInstanceId === undefined) ev.questInstanceId = null;
      });
    }
    return merged;
  }

  // Returns a Promise resolving to the loaded/migrated/default state. Only the app's boot
  // sequence awaits this — every other call site keeps using the synchronous-looking
  // get()/save() below, since by the time any UI handler runs, state is already populated.
  function init(u) {
    uid = u;
    return Forge.Storage.load(uid).then(function (result) {
      if (result.source === 'firestore') {
        state = migrate(result.data);
      } else if (result.source === 'legacy') {
        // one-time promotion of a pre-auth localStorage save into this account's Firestore doc
        state = migrate(result.data);
        Forge.Storage.save(state, uid);
      } else {
        state = defaultState();
        Forge.Storage.save(state, uid);
      }
      return state;
    });
  }

  function get() { return state; }

  function replace(newState) { state = newState; }

  function save() {
    Forge.Storage.save(state, uid);
  }

  // Sends any pending debounced write immediately — use before a restart/sign-out so an
  // in-flight change is never lost or read back stale.
  function flush() {
    return Forge.Storage.flush();
  }

  function getUid() { return uid; }

  function reset() {
    state = null;
    uid = null;
  }

  return {
    init: init,
    get: get,
    replace: replace,
    save: save,
    flush: flush,
    getUid: getUid,
    reset: reset,
    todayStr: todayStr,
    defaultState: defaultState
  };
})();

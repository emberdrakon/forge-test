// Daily Forge 2.0 — Firestore-backed persistence layer, with a per-account
// localStorage cache (instant reads/writes) and a debounced write queue.
window.Forge = window.Forge || {};

Forge.Storage = (function () {
  var LEGACY_KEY = 'daily-forge-2:state'; // pre-auth, unnamespaced save
  function cacheKey(uid) { return 'daily-forge-2:state:' + uid; }

  // Resolves { source: 'firestore' | 'legacy' | 'none', data } — state.js decides what to do
  // with each source (migrate/default/push), storage.js just reports where data came from.
  function load(uid) {
    return Forge.Firebase.db.collection('users').doc(uid).get().then(function (snap) {
      if (snap.exists) {
        try { localStorage.setItem(cacheKey(uid), JSON.stringify(snap.data())); } catch (e) {}
        return { source: 'firestore', data: snap.data() };
      }
      var legacyRaw = null;
      try { legacyRaw = localStorage.getItem(LEGACY_KEY); } catch (e) {}
      if (legacyRaw) {
        try { return { source: 'legacy', data: JSON.parse(legacyRaw) }; } catch (e) { /* fall through */ }
      }
      return { source: 'none', data: null };
    });
  }

  var pendingTimer = null, pendingState = null, pendingUid = null, firstPendingAt = null;
  var DEBOUNCE_MS = 1500, MAX_WAIT_MS = 6000;

  function save(state, uid) {
    try { localStorage.setItem(cacheKey(uid), JSON.stringify(state)); } catch (e) {
      console.warn('[Forge.Storage] failed to write local cache', e);
    }
    pendingState = state;
    pendingUid = uid;
    if (!firstPendingAt) firstPendingAt = Date.now();
    if (pendingTimer) clearTimeout(pendingTimer);
    var wait = (Date.now() - firstPendingAt >= MAX_WAIT_MS) ? 0 : DEBOUNCE_MS;
    pendingTimer = setTimeout(flush, wait);
  }

  // Sends any pending write immediately. Call this before a reload/restart or when the
  // page is being hidden, so a debounce window never becomes a real data-loss window.
  function flush() {
    if (pendingTimer) { clearTimeout(pendingTimer); pendingTimer = null; }
    if (!pendingState) return Promise.resolve();
    var s = pendingState, u = pendingUid;
    pendingState = null;
    pendingUid = null;
    firstPendingAt = null;
    return Forge.Firebase.db.collection('users').doc(u).set(s).catch(function (e) {
      console.warn('[Forge.Storage] firestore write failed', e);
    });
  }

  function exportBackup(state) {
    var blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    var d = new Date();
    var stamp = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    a.href = url;
    a.download = 'daily-forge-backup-' + stamp + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  }

  function importBackup(file, cb) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var parsed = JSON.parse(reader.result);
        cb(null, parsed);
      } catch (e) {
        cb(e, null);
      }
    };
    reader.onerror = function () { cb(reader.error, null); };
    reader.readAsText(file);
  }

  return {
    load: load,
    save: save,
    flush: flush,
    exportBackup: exportBackup,
    importBackup: importBackup,
    LEGACY_KEY: LEGACY_KEY,
    cacheKey: cacheKey
  };
})();

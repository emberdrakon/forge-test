// Daily Forge 2.0 — achievements. getProgress(state) returns a number; unlocked at >= target.
window.Forge = window.Forge || {};
Forge.Data = Forge.Data || {};

Forge.Data.ACHIEVEMENTS = [
  { id: 'first_steps', name: 'First Steps', desc: 'Complete your first quest.', icon: 'footprint', target: 1,
    getProgress: function (s) { return Math.min(1, s.counters.questsCompleted); } },
  { id: 'builder', name: 'Builder', desc: 'Complete 50 quests.', icon: 'craft', target: 50,
    getProgress: function (s) { return s.counters.questsCompleted; } },
  { id: 'consistent', name: 'Consistent', desc: 'Reach a 7 day streak.', icon: 'flame', target: 7,
    getProgress: function (s) { return s.counters.maxStreak; } },
  { id: 'unbreakable', name: 'Unbreakable', desc: 'Reach a 30 day streak.', icon: 'flame', target: 30,
    getProgress: function (s) { return s.counters.maxStreak; } },
  { id: 'early_bird', name: 'Early Bird', desc: 'Complete 10 quests before 8am.', icon: 'sound', target: 10,
    getProgress: function (s) { return s.counters.earlyBirdCount; } },
  { id: 'night_owl', name: 'Night Owl', desc: 'Complete 10 quests after 10pm.', icon: 'mute', target: 10,
    getProgress: function (s) { return s.counters.nightOwlCount; } },
  { id: 'forge_master', name: 'Forge Master', desc: 'Craft 10 items.', icon: 'tool', target: 10,
    getProgress: function (s) { return s.counters.craftsMade; } },
  { id: 'scholar', name: 'Scholar', desc: 'Reach Knowledge skill level 10.', icon: 'book', target: 10,
    getProgress: function (s) { return Forge.Data.skillLevel(s.skills.knowledge.xp); } },
  { id: 'dungeon_survivor', name: 'Dungeon Survivor', desc: 'Complete 20 quests in the Corporate Dungeon.', icon: 'shield', target: 20,
    getProgress: function (s) { return s.counters.dungeonQuests; } },
  { id: 'explorer', name: 'Explorer', desc: 'Visit every area on the World Map.', icon: 'map', target: Forge.Data.AREAS ? Forge.Data.AREAS.length : 7,
    getProgress: function (s) { return Object.keys(s.counters.areasVisited || {}).length; } },
  { id: 'ironclad', name: 'Ironclad', desc: 'Fill every equipment slot.', icon: 'armor', target: 5,
    getProgress: function (s) { return Object.values(s.equipment.slots).filter(Boolean).length; } },
  { id: 'collector', name: 'Collector', desc: 'Hold 5 different materials at once.', icon: 'crystal', target: 5,
    getProgress: function (s) { return Object.values(s.inventory.materials).filter(function (n) { return n > 0; }).length; } },
  { id: 'well_rounded', name: 'Well-Rounded', desc: 'Reach level 5 in four different skills.', icon: 'star', target: 4,
    getProgress: function (s) { return Object.values(s.skills).filter(function (sk) { return Forge.Data.skillLevel(sk.xp) >= 5; }).length; } },
  { id: 'firestarter', name: 'Firestarter', desc: 'Reach a full Temper Gauge.', icon: 'flame', target: 1,
    getProgress: function (s) { return s.counters.maxTemper >= 100 ? 1 : 0; } },
  { id: 'legend', name: 'Legend', desc: 'Reach character level 25.', icon: 'trophy', target: 25,
    getProgress: function (s) { return Forge.Engine.level(s.character.totalXP); } },
  { id: 'boss_slayer', name: 'Boss Slayer', desc: 'Clear your first boss.', icon: 'boss', target: 1,
    getProgress: function (s) { return s.counters.bossesCleared; } }
];

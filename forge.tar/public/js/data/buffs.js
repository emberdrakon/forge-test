// Daily Forge 2.0 — buff & debuff catalog (effects are flavor + small display-only bonuses)
window.Forge = window.Forge || {};
Forge.Data = Forge.Data || {};

Forge.Data.BUFFS = {
  well_rested: { name: 'Well Rested', icon: 'check', desc: 'Yesterday’s forge ran hot. You start today ahead.' },
  hydrated: { name: 'Hydrated', icon: 'potion', desc: 'Sharper, steadier, ready.' },
  runners_high: { name: "Runner's High", icon: 'sword', desc: 'The body is warmed up and willing.' },
  inspired: { name: 'Inspired', icon: 'crystal', desc: 'Ideas are coming easily today.' },
  focused: { name: 'Focused', icon: 'accessory', desc: 'The noise has faded. The work is clear.' },
  on_a_roll: { name: 'On a Roll', icon: 'flame', desc: 'Momentum is on your side.' }
};

Forge.Data.DEBUFFS = {
  rust: { name: 'Rust', icon: 'reset', desc: 'A day was missed. The edge has dulled slightly — one quest will shake it off.' },
  sleep_deprived: { name: 'Sleep Deprived', icon: 'mute', desc: 'Save & Quit was missed last night. Rest before the watch tonight.' },
  hungry: { name: 'Hungry', icon: 'potion', desc: 'Yesterday’s meals were skipped. Eat something today to shake this off.' },
  burnout: { name: 'Burnout', icon: 'reset', desc: 'Several hard days in a row. Consider a lighter one.' },
  distracted: { name: 'Distracted', icon: 'mute', desc: 'Focus is scattered right now.' }
};

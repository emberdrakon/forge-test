// Daily Forge 2.0 — seasonal event types & their rewards
window.Forge = window.Forge || {};
Forge.Data = Forge.Data || {};

// Each preset grants a one-time bundle of materials plus a same-day buff when its date arrives.
// Most also grant a themed piece of equipment the first time that event type ever pays out
// (equipment is a one-time unlock — repeat events of the same type won't hand out a second copy).
// 'custom' is the fallback used for events that don't match a known type (or older saved events).
Forge.Data.EVENT_TYPES = [
  { id: 'anniversary', label: '🍂 Forge Anniversary', icon: 'trophy', buff: 'on_a_roll',
    materials: { iron_ore: 5, coal: 4, crystal: 3 },
    equipment: 'founders_hammer',
    flavor: 'Another year at the anvil.' },
  { id: 'convention', label: '🎭 Cosplay Conventions', icon: 'armor', buff: 'inspired',
    materials: { leather: 4, crystal: 3 },
    equipment: 'convention_badge',
    flavor: 'A gathering of fellow craftspeople.' },
  { id: 'forge_projects', label: '⚒ Forge Projects', icon: 'craft', buff: 'focused',
    materials: { iron_ore: 3, coal: 3, ember_dust: 3 },
    equipment: 'journeymans_plate',
    flavor: 'Something real, built with your own hands.' },
  { id: 'oontz', label: '🎵 Oontz', icon: 'sound', buff: 'runners_high',
    materials: { ember_dust: 3, crystal: 3, phoenix_feather: 1 },
    equipment: 'neon_ferret',
    flavor: 'The bass hasn’t stopped in hours.' },
  { id: 'guild', label: '🤝 Guild Gatherings', icon: 'character', buff: 'well_rested',
    materials: { leather: 2, herbs: 3, knowledge_scroll: 1 },
    equipment: 'guildmark_circlet',
    flavor: 'Good company, traded stories, no rush to leave.' },
  { id: 'custom', label: '🎉 Celebrations', icon: 'star', buff: 'focused',
    materials: { ember_dust: 3, herbs: 3 },
    equipment: null,
    flavor: 'A day worth marking.' }
];

Forge.Data.getEventType = function (typeId) {
  return Forge.Data.EVENT_TYPES.find(function (t) { return t.id === typeId; }) || Forge.Data.EVENT_TYPES[Forge.Data.EVENT_TYPES.length - 1];
};

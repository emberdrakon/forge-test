// Daily Forge 2.0 — Ember, the forge spirit. Never guilts the player.
window.Forge = window.Forge || {};
Forge.Data = Forge.Data || {};

Forge.Data.COMPANION_NAME = 'Ember';

Forge.Data.COMPANION_LINES = {
  greetingMorning: [
    'The forge still burns.',
    'Welcome back.',
    'Morning. The fire kept itself company.',
    'Ready when you are.'
  ],
  greetingAfternoon: [
    'The fire waited for you.',
    'Good to see you again.',
    'The forge is warm. Add to it or don’t — it’ll keep.'
  ],
  greetingEvening: [
    'The forge glows quieter at this hour.',
    'A late visit. Still counts.',
    'Evening. No rush.'
  ],
  returningAfterGap: [
    'You’ve been away. The forge kept your place.',
    'Nothing was lost while you were gone.',
    'Welcome back — pick up wherever suits you.'
  ],
  streakMilestone: [
    'That’s a long stretch of steady fire.',
    'The forge has never run this hot for this long.',
    'Consistency like this reshapes steel. And people.'
  ],
  levelUp: [
    'Something in you just shifted.',
    'You’re not who you were yesterday.',
    'The hammer strikes true again.'
  ],
  highTemper: [
    'The forge is roaring today.',
    'This is a good day to build something.',
    'You’re burning bright.'
  ],
  lowTemper: [
    'A quiet fire is still a fire.',
    'You’ve earned your rest.',
    'No forge burns at full heat forever.',
    'Slow days temper the steel too.'
  ],
  questComplete: [
    'One more piece shaped.',
    'The anvil rings true.',
    'Good work.',
    'That’ll hold.'
  ],
  bossUpcoming: [
    'Something big is coming. You’re preparing well.',
    'The tower doesn’t move. Neither do you, apparently.'
  ],
  idle: [
    'The forge doesn’t mind waiting.',
    'Whenever you’re ready.',
    'No fire burns out from one quiet day.'
  ]
};

Forge.Data.pickLine = function (category) {
  var lines = Forge.Data.COMPANION_LINES[category] || Forge.Data.COMPANION_LINES.idle;
  return lines[Math.floor(Math.random() * lines.length)];
};

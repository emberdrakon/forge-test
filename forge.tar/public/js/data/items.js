// Daily Forge 2.0 — materials, consumables, equipment, cosmetics, recipes, drop tables
window.Forge = window.Forge || {};
Forge.Data = Forge.Data || {};

Forge.Data.MATERIALS = [
  { id: 'iron_ore', name: 'Iron Ore', icon: 'ore', rarity: 'common', flavor: 'Raw strength, waiting to be shaped.' },
  { id: 'coal', name: 'Coal', icon: 'coal', rarity: 'common', flavor: 'Fuel for the fire.' },
  { id: 'leather', name: 'Leather', icon: 'leather', rarity: 'common', flavor: 'Tough and pliable.' },
  { id: 'herbs', name: 'Wild Herbs', icon: 'herb', rarity: 'common', flavor: 'Gathered along the way.' },
  { id: 'ember_dust', name: 'Ember Dust', icon: 'dust', rarity: 'common', flavor: 'Glowing residue of hard work.' },
  { id: 'ancient_pages', name: 'Ancient Pages', icon: 'page', rarity: 'uncommon', flavor: 'Fragments of forgotten knowledge.' },
  { id: 'knowledge_scroll', name: 'Knowledge Scroll', icon: 'scroll', rarity: 'uncommon', flavor: 'A sealed lesson, ready to unroll.' },
  { id: 'crystal', name: 'Charged Crystal', icon: 'crystal', rarity: 'uncommon', flavor: 'Hums with stored focus.' },
  { id: 'phoenix_feather', name: 'Phoenix Feather', icon: 'feather', rarity: 'rare', flavor: 'It should have burned. It didn’t.' },
  { id: 'obsidian_shard', name: 'Obsidian Shard', icon: 'shard', rarity: 'rare', flavor: 'Cooled from something far hotter.' }
];

Forge.Data.CONSUMABLES = [
  { id: 'health_tonic', name: 'Vitality Tonic', icon: 'potion', rarity: 'common', effect: 'temper', amount: 12, flavor: 'Restores your temper by 12.' },
  { id: 'focus_brew', name: 'Focus Brew', icon: 'potion', rarity: 'uncommon', effect: 'buff', buffId: 'focused', flavor: 'Grants Focused for the rest of the day.' },
  { id: 'rest_essence', name: 'Rest Essence', icon: 'potion', rarity: 'uncommon', effect: 'buff', buffId: 'well_rested', flavor: 'Grants Well Rested for the rest of the day.' }
];

Forge.Data.EQUIPMENT = [
  { id: 'iron_helm', name: 'Iron Helm', slot: 'helmet', icon: 'helmet', bonus: { stat: 'vitality', amount: 2 }, source: 'craft', flavor: 'Simple. Sturdy. Yours.' },
  { id: 'thinking_cap', name: 'Thinking Cap', slot: 'helmet', icon: 'helmet', bonus: { stat: 'knowledge', amount: 3 }, source: 'craft', flavor: 'Woven from old lecture notes.' },
  { id: 'wardens_visor', name: "Warden's Visor", slot: 'helmet', icon: 'helmet', bonus: { stat: 'vitality', amount: 3 }, source: 'craft', flavor: 'Keeps the sweat out of your eyes.' },
  { id: 'guildmark_circlet', name: 'Guildmark Circlet', slot: 'helmet', icon: 'helmet', bonus: { stat: 'social', amount: 4 }, source: 'event', flavor: 'Marked with everyone who was there.' },
  { id: 'warden_plate', name: 'Warden Plate', slot: 'armor', icon: 'armor', bonus: { stat: 'vitality', amount: 4 }, source: 'craft', flavor: 'Forged for those who show up daily.' },
  { id: 'traveling_cloak', name: 'Traveling Cloak', slot: 'armor', icon: 'armor', bonus: { stat: 'social', amount: 3 }, source: 'loot', flavor: 'Smells faintly of distant roads.' },
  { id: 'ember_forged_plate', name: 'Ember-Forged Plate', slot: 'armor', icon: 'armor', bonus: { stat: 'strength', amount: 3 }, source: 'craft', flavor: 'Quenched in coal-smoke, not water.' },
  { id: 'journeymans_plate', name: "Journeyman's Plate", slot: 'armor', icon: 'armor', bonus: { stat: 'creativity', amount: 4 }, source: 'event', flavor: 'Every dent tells you what you built.' },
  { id: 'noise_cancelling_headphones', name: 'Noise-Cancelling Headphones', slot: 'accessory', icon: 'accessory', bonus: { stat: 'discipline', amount: 5 }, source: 'loot', flavor: 'The world goes quiet. The work gets loud.' },
  { id: 'focus_band', name: 'Focus Band', slot: 'accessory', icon: 'accessory', bonus: { stat: 'knowledge', amount: 3 }, source: 'craft', flavor: 'A thin crystal thread around the wrist.' },
  { id: 'steady_hands_ring', name: 'Steady Hands Ring', slot: 'accessory', icon: 'accessory', bonus: { stat: 'discipline', amount: 3 }, source: 'craft', flavor: 'Cut from a crystal that never rushes.' },
  { id: 'convention_badge', name: 'Convention Badge', slot: 'accessory', icon: 'accessory', bonus: { stat: 'social', amount: 4 }, source: 'event', flavor: 'Covered in traded pins.' },
  { id: 'ember_pup', name: 'Ember Pup', slot: 'pet', icon: 'pet', bonus: { stat: 'social', amount: 2 }, source: 'craft', flavor: 'Follows you everywhere. Never judges.' },
  { id: 'stone_owl', name: 'Stone Owl', slot: 'pet', icon: 'pet', bonus: { stat: 'knowledge', amount: 2 }, source: 'craft', flavor: 'Watches over your studies in silence.' },
  { id: 'marketplace_cat', name: 'Marketplace Cat', slot: 'pet', icon: 'pet', bonus: { stat: 'vitality', amount: 2 }, source: 'loot', flavor: 'Adopted you. Not the other way around.' },
  { id: 'neon_ferret', name: 'Neon Ferret', slot: 'pet', icon: 'pet', bonus: { stat: 'creativity', amount: 3 }, source: 'event', flavor: 'Hasn’t stopped vibrating since Oontz.' },
  { id: 'mechanical_keyboard', name: 'Mechanical Keyboard', slot: 'tool', icon: 'tool', bonus: { stat: 'discipline', amount: 3 }, source: 'loot', flavor: 'Every keystroke sounds like progress.' },
  { id: 'forge_hammer', name: 'Forge Hammer', slot: 'tool', icon: 'tool', bonus: { stat: 'strength', amount: 3 }, source: 'craft', flavor: 'Heavy in the hand, light on the soul.' },
  { id: 'precision_chisel', name: 'Precision Chisel', slot: 'tool', icon: 'tool', bonus: { stat: 'creativity', amount: 3 }, source: 'craft', flavor: 'For the details no one else notices.' },
  { id: 'founders_hammer', name: "Founder's Hammer", slot: 'tool', icon: 'tool', bonus: { stat: 'discipline', amount: 4 }, source: 'event', flavor: 'Passed down every Forge Anniversary.' }
];

Forge.Data.COSMETICS = [
  { id: 'forgesteel', name: 'Ember & Steel', kind: 'theme', flavor: 'The forge as it has always been.' },
  { id: 'steelhud', name: 'Steel HUD', kind: 'theme', flavor: 'A colder, sharper interface.' },
  { id: 'goldenforge', name: 'Golden Forge', kind: 'theme', flavor: 'The forge burns gold for the worthy.' },
  { id: 'cursor_ember', name: 'Ember Cursor', kind: 'toggle', attr: 'cursor', value: 'ember', flavor: 'Your cursor trails embers.' },
  { id: 'bg_embers', name: 'Drifting Embers', kind: 'toggle', attr: 'embers', value: '1', flavor: 'Embers drift quietly across the world.' }
];

Forge.Data.RECIPES = [
  { id: 'craft_steelhud', name: 'Steel HUD', icon: 'shield', cosmeticId: 'steelhud', cost: { iron_ore: 4, leather: 2 } },
  { id: 'craft_goldenforge', name: 'Golden Forge', icon: 'crystal', cosmeticId: 'goldenforge', cost: { crystal: 3, phoenix_feather: 1 } },
  { id: 'craft_embercursor', name: 'Ember Cursor', icon: 'flame', cosmeticId: 'cursor_ember', cost: { coal: 2, ember_dust: 2 } },
  { id: 'craft_driftingembers', name: 'Drifting Embers', icon: 'dust', cosmeticId: 'bg_embers', cost: { herbs: 3, ember_dust: 2 } },
  { id: 'craft_ironhelm', name: 'Iron Helm', icon: 'helmet', itemId: 'iron_helm', cost: { iron_ore: 5 } },
  { id: 'craft_thinkingcap', name: 'Thinking Cap', icon: 'helmet', itemId: 'thinking_cap', cost: { ancient_pages: 4, knowledge_scroll: 1 } },
  { id: 'craft_wardenplate', name: 'Warden Plate', icon: 'armor', itemId: 'warden_plate', cost: { iron_ore: 6, leather: 3 } },
  { id: 'craft_focusband', name: 'Focus Band', icon: 'accessory', itemId: 'focus_band', cost: { crystal: 2, knowledge_scroll: 1 } },
  { id: 'craft_forgehammer', name: 'Forge Hammer', icon: 'tool', itemId: 'forge_hammer', cost: { iron_ore: 3, coal: 2 } },
  { id: 'craft_emberpup', name: 'Ember Pup', icon: 'pet', itemId: 'ember_pup', cost: { phoenix_feather: 1, crystal: 1 } },
  { id: 'craft_stoneowl', name: 'Stone Owl', icon: 'pet', itemId: 'stone_owl', cost: { obsidian_shard: 1, ancient_pages: 2 } },
  { id: 'craft_wardensvisor', name: "Warden's Visor", icon: 'helmet', itemId: 'wardens_visor', cost: { iron_ore: 4, leather: 2 } },
  { id: 'craft_emberforgedplate', name: 'Ember-Forged Plate', icon: 'armor', itemId: 'ember_forged_plate', cost: { coal: 4, iron_ore: 3 } },
  { id: 'craft_steadyhandsring', name: 'Steady Hands Ring', icon: 'accessory', itemId: 'steady_hands_ring', cost: { crystal: 2, iron_ore: 2 } },
  { id: 'craft_precisionchisel', name: 'Precision Chisel', icon: 'tool', itemId: 'precision_chisel', cost: { leather: 3, crystal: 1 } }
];

// area -> material drop table used by the engine when a quest completes there
Forge.Data.DROP_TABLES = {
  homeVillage: [{ id: 'herbs', chance: 0.5, min: 1, max: 2 }, { id: 'leather', chance: 0.25, min: 1, max: 1 }],
  forge: [{ id: 'iron_ore', chance: 0.55, min: 1, max: 2 }, { id: 'coal', chance: 0.4, min: 1, max: 2 }, { id: 'ember_dust', chance: 0.3, min: 1, max: 1 }],
  library: [{ id: 'ancient_pages', chance: 0.5, min: 1, max: 2 }, { id: 'knowledge_scroll', chance: 0.25, min: 1, max: 1 }],
  corporateDungeon: [{ id: 'coal', chance: 0.4, min: 1, max: 2 }, { id: 'crystal', chance: 0.22, min: 1, max: 1 }, { id: 'iron_ore', chance: 0.3, min: 1, max: 1 }],
  marketplace: [{ id: 'leather', chance: 0.4, min: 1, max: 2 }, { id: 'herbs', chance: 0.35, min: 1, max: 1 }],
  arena: [{ id: 'iron_ore', chance: 0.45, min: 1, max: 2 }, { id: 'leather', chance: 0.3, min: 1, max: 1 }],
  bossTower: [{ id: 'crystal', chance: 0.4, min: 1, max: 2 }, { id: 'obsidian_shard', chance: 0.08, min: 1, max: 1 }]
};

Forge.Data.RARE_GLOBAL_DROPS = [
  { id: 'phoenix_feather', chance: 0.025, min: 1, max: 1 },
  { id: 'obsidian_shard', chance: 0.02, min: 1, max: 1 }
];

// rare equipment that can only be found in the field, never crafted
Forge.Data.RARE_EQUIPMENT_DROPS = [
  { id: 'noise_cancelling_headphones', chance: 0.012 },
  { id: 'mechanical_keyboard', chance: 0.012 },
  { id: 'traveling_cloak', chance: 0.015 },
  { id: 'marketplace_cat', chance: 0.015 }
];

(function () {
  var index = {};
  Forge.Data.MATERIALS.forEach(function (m) { index[m.id] = Object.assign({ kind: 'material' }, m); });
  Forge.Data.CONSUMABLES.forEach(function (m) { index[m.id] = Object.assign({ kind: 'consumable' }, m); });
  Forge.Data.EQUIPMENT.forEach(function (m) { index[m.id] = Object.assign({ kind: 'equipment' }, m); });
  Forge.Data.ITEM_INDEX = index;
  Forge.Data.getItem = function (id) { return index[id] || null; };
})();

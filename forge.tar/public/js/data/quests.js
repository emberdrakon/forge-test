// Daily Forge 2.0 — quest template catalog
window.Forge = window.Forge || {};
Forge.Data = Forge.Data || {};

// type: 'daily' (required, counts toward streak) | 'side' (recurring, optional)
// section groups quests on the board: Daily, Work, Evening, Side
// area ties the quest to a World Map location. stat/skill are gained on completion.
// grantsBuff: completing it grants that buff for the rest of the day (used for the meal quest).
// mealQuest / sleepQuest: flagged so the engine can raise Hungry / Sleep Deprived the next day if missed.
// weekdaysOnly: only appears on the board Monday–Friday.
Forge.Data.SECTION_ORDER = ['Daily', 'Work', 'Evening', 'Side'];

Forge.Data.QUEST_TEMPLATES = [
  // ---- Daily ----
  { id: 'tend_the_forge', title: 'Tend the Forge', time: '', flavor: 'Start the day by stoking your own fire.', type: 'daily', section: 'Daily', area: 'forge', stat: 'discipline', xp: 10 },
  { id: 'drink_the_well', title: 'Drink the Well Dry', time: '', flavor: 'Water first. Everything else after.', type: 'daily', section: 'Daily', area: 'homeVillage', stat: 'vitality', xp: 8 },
  { id: 'move_your_body', title: 'Move Your Body', time: '', flavor: 'Train at the Arena — any movement counts.', type: 'daily', section: 'Daily', area: 'arena', stat: 'strength', skill: 'fitness', xp: 22 },
  { id: 'sharpen_the_mind', title: 'Sharpen the Mind', time: '', flavor: 'Twenty minutes among the trees of Library Forest.', type: 'daily', section: 'Daily', area: 'library', stat: 'knowledge', skill: 'knowledge', xp: 20 },
  { id: 'tidy_the_camp', title: 'Tidy the Camp', time: '', flavor: 'A clear camp, a clear head.', type: 'daily', section: 'Daily', area: 'homeVillage', stat: 'discipline', xp: 10 },
  { id: 'rest_before_watch', title: 'Rest Before the Watch', time: '', flavor: 'Sleep on time. The forge banks its coals too.', type: 'daily', section: 'Daily', area: 'homeVillage', stat: 'vitality', xp: 15, sleepQuest: true },
  { id: 'consumable_meal', title: 'Consumable: Meal', time: '', flavor: 'Eat something real. Energy and focus, a few hours’ worth.', type: 'daily', section: 'Daily', area: 'homeVillage', stat: 'vitality', xp: 10, grantsBuff: 'focused', mealQuest: true },

  // ---- Work (weekdays only) ----
  { id: 'dungeon_morning', title: 'Corporate Dungeon — Morning Wing', time: '8:00 AM – 1:00 PM', flavor: 'Tickets, meetings, the usual boss fights.', type: 'daily', section: 'Work', area: 'corporateDungeon', stat: 'discipline', skill: 'career', xp: 25, weekdaysOnly: true },
  { id: 'dungeon_afternoon', title: 'Corporate Dungeon — Afternoon Wing', time: '1:00 – 5:00 PM', flavor: 'Close the loop on today’s objectives.', type: 'daily', section: 'Work', area: 'corporateDungeon', stat: 'discipline', skill: 'career', xp: 25, weekdaysOnly: true },

  // ---- Evening (optional) ----
  { id: 'skill_armorsmithing', title: 'Skill Tree: Armorsmithing', time: 'Free Roam', flavor: 'Work the current cosplay build.', type: 'side', section: 'Evening', area: 'forge', stat: 'creativity', xp: 35 },
  { id: 'skill_guitar', title: 'Skill Tree: Guitar', time: 'Free Roam', flavor: 'Practice reps — pick a song or drill.', type: 'side', section: 'Evening', area: 'forge', stat: 'creativity', skill: 'music', xp: 30 },
  { id: 'skill_study', title: 'Skill Tree: Study', time: 'Free Roam', flavor: 'Whatever’s next on the list.', type: 'side', section: 'Evening', area: 'library', stat: 'knowledge', skill: 'knowledge', xp: 30 },

  // ---- Side ----
  { id: 'call_an_ally', title: 'Call an Ally', time: '', flavor: 'Reach out to someone at the Marketplace of life.', type: 'side', section: 'Side', area: 'marketplace', stat: 'social', xp: 16 },
  { id: 'cook_from_scratch', title: 'Cook From Scratch', time: '', flavor: 'A meal made, not bought.', type: 'side', section: 'Side', area: 'marketplace', stat: 'vitality', skill: 'cooking', xp: 16 },
  { id: 'study_the_scrolls', title: 'Study the Scrolls', time: '', flavor: 'Extra study beyond the daily grind.', type: 'side', section: 'Side', area: 'library', stat: 'knowledge', skill: 'knowledge', xp: 18 },
  { id: 'forge_in_code', title: 'Forge in Code', time: '', flavor: 'Build or learn something with your hands on a keyboard.', type: 'side', section: 'Side', area: 'forge', stat: 'knowledge', skill: 'programming', xp: 22 },
  { id: 'plan_tomorrow', title: "Chart Tomorrow's Route", time: '', flavor: 'A short look at the road ahead.', type: 'side', section: 'Side', area: 'homeVillage', stat: 'discipline', xp: 12 }
];

Forge.Data.AREA_NAME = function (id) {
  var a = Forge.Data.AREAS && Forge.Data.AREAS.find(function (x) { return x.id === id; });
  return a ? a.name : id;
};

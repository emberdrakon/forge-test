// Daily Forge 2.0 — long-term skill trees
window.Forge = window.Forge || {};
Forge.Data = Forge.Data || {};

Forge.Data.SKILLS = [
  { id: 'knowledge', name: 'Knowledge', icon: 'book', desc: 'Study, reading, learning anything new.' },
  { id: 'fitness', name: 'Fitness', icon: 'sword', desc: 'Training, movement, physical effort.' },
  { id: 'creativity', name: 'Creativity', icon: 'crystal', desc: 'Art, writing, making things that didn’t exist before.' },
  { id: 'career', name: 'Career', icon: 'shield', desc: 'Deep, focused professional work.' },
  { id: 'music', name: 'Music', icon: 'star', desc: 'Practice, performance, sound.' },
  { id: 'cooking', name: 'Cooking', icon: 'flame', desc: 'Meals made with your own hands.' },
  { id: 'programming', name: 'Programming', icon: 'craft', desc: 'Code, tools, systems you build.' }
];

Forge.Data.SKILL_XP_LEVEL_1 = 500;
Forge.Data.SKILL_XP_PER_LEVEL = 800;

// Level 1 -> 2 costs SKILL_XP_LEVEL_1 xp; every level after that costs SKILL_XP_PER_LEVEL.
Forge.Data.skillLevelInfo = function (xp) {
  xp = xp || 0;
  var level = 1;
  var remaining = xp;
  var per = Forge.Data.SKILL_XP_LEVEL_1;
  while (remaining >= per) {
    remaining -= per;
    level++;
    per = Forge.Data.SKILL_XP_PER_LEVEL;
  }
  return { level: level, into: remaining, per: per };
};

Forge.Data.skillLevel = function (xp) {
  return Forge.Data.skillLevelInfo(xp).level;
};

Forge.Data.skillIntoLevel = function (xp) {
  return Forge.Data.skillLevelInfo(xp).into;
};

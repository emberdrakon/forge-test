// Daily Forge 2.0 — world map areas & connecting paths
window.Forge = window.Forge || {};
Forge.Data = Forge.Data || {};

Forge.Data.AREAS = [
  { id: 'homeVillage', name: 'Home Village', icon: 'home', unlockLevel: 1, x: 14, y: 80, desc: 'Where the journey begins each morning.' },
  { id: 'forge', name: 'The Forge', icon: 'craft', unlockLevel: 1, x: 30, y: 56, desc: 'Where raw effort becomes craft.' },
  { id: 'marketplace', name: 'Marketplace', icon: 'bag', unlockLevel: 1, x: 44, y: 82, desc: 'Trade, gather, and prepare.' },
  { id: 'library', name: 'Library Forest', icon: 'book', unlockLevel: 2, x: 54, y: 30, desc: 'Ancient knowledge hides among the trees.' },
  { id: 'arena', name: 'Arena', icon: 'sword', unlockLevel: 3, x: 74, y: 64, desc: 'Strength is tested here.' },
  { id: 'corporateDungeon', name: 'Corporate Dungeon', icon: 'shield', unlockLevel: 5, x: 68, y: 20, desc: 'Descend into the grind. Emerge stronger.' },
  { id: 'bossTower', name: 'Boss Tower', icon: 'boss', unlockLevel: 8, x: 88, y: 10, desc: 'Where your hardest trials await.' }
];

Forge.Data.WORLD_PATHS = [
  ['homeVillage', 'forge'],
  ['homeVillage', 'marketplace'],
  ['forge', 'library'],
  ['forge', 'arena'],
  ['library', 'corporateDungeon'],
  ['arena', 'corporateDungeon'],
  ['corporateDungeon', 'bossTower'],
  ['arena', 'bossTower']
];

// Daily Forge 2.0 — Achievements screen
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Achievements = (function () {
  function render(state) {
    var unlockedCount = Object.keys(state.achievements.unlocked).length;
    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Achievements</div><div class="forge-screen-sub">' + unlockedCount + ' / ' + Forge.Data.ACHIEVEMENTS.length + ' unlocked</div></div>';

    Forge.Data.ACHIEVEMENTS.forEach(function (a) {
      var unlocked = !!state.achievements.unlocked[a.id];
      var progress = Math.min(a.target, a.getProgress(state));
      var pct = Math.round((progress / a.target) * 100);
      html += '<div class="forge-ach-card' + (unlocked ? ' unlocked' : '') + ' forge-anim-in">';
      html += '  <div class="forge-ach-icon">' + Forge.Icons.svg(a.icon) + '</div>';
      html += '  <div class="forge-ach-body">';
      html += '    <div class="forge-ach-name">' + a.name + '</div>';
      html += '    <div class="forge-ach-desc">' + a.desc + '</div>';
      if (!unlocked) {
        html += '    <div class="forge-bar-track forge-bar-sm"><div class="forge-bar-fill forge-bar-sm" style="width:' + pct + '%"></div></div>';
        html += '    <div style="font-size:9.5px;color:var(--muted);margin-top:3px;" class="f-mono">' + progress + ' / ' + a.target + '</div>';
      }
      html += '  </div>';
      html += '</div>';
    });

    html += '</div>';
    return html;
  }

  function mount() {}

  return { render: render, mount: mount };
})();

// Daily Forge 2.0 — Boss Tower (exams & major trials)
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Bosses = (function () {
  var showAddForm = false;

  function daysUntil(dateStr) {
    var today = Forge.State.todayStr();
    return Math.round((new Date(dateStr + 'T00:00:00') - new Date(today + 'T00:00:00')) / 86400000);
  }

  function bossCard(state, boss) {
    var chance = Forge.Engine.bossSuccessChance(state, boss);
    var days = daysUntil(boss.date);
    var stars = '★★★★★'.slice(0, boss.difficulty) + '☆☆☆☆☆'.slice(0, 5 - boss.difficulty);
    var html = '<div class="forge-boss-card forge-anim-in">';
    html += '  <div class="forge-row" style="justify-content:space-between;align-items:flex-start;">';
    html += '    <div><div class="forge-boss-name">' + boss.name + '</div>';
    html += '    <div class="forge-boss-meta">' + (boss.cleared ? 'Cleared' : (days < 0 ? 'Passed' : days === 0 ? 'Today' : 'In ' + days + ' day' + (days === 1 ? '' : 's'))) + ' &middot; Recommended Lv ' + boss.recommendedLevel + '</div></div>';
    html += '    <span class="forge-boss-stars">' + stars + '</span>';
    html += '  </div>';
    if (!boss.cleared) {
      html += '  <div class="forge-boss-stat"><span>Preparation</span><span class="f-mono">' + boss.prep + '%</span></div>';
      html += '  <div class="forge-bar-track forge-bar-sm"><div class="forge-bar-fill forge-bar-sm" style="width:' + boss.prep + '%"></div></div>';
      html += '  <div class="forge-boss-stat"><span>Success Chance</span><span class="forge-boss-chance" style="color:' + (chance >= 60 ? 'var(--ok)' : chance >= 35 ? 'var(--gold)' : 'var(--bad)') + '">' + chance + '%</span></div>';
      var preview = Forge.Engine.bossRewardPreview(boss.difficulty);
      var matNames = Object.keys(preview.materials).map(function (id) {
        var item = Forge.Data.getItem(id);
        return (item ? item.name : id) + ' x' + preview.materials[id];
      }).join(', ');
      html += '  <div style="font-size:10.5px;color:var(--muted);margin-top:8px;">Reward: ' + preview.xp + ' XP, ' + matNames + ', and a chance at rarer materials.</div>';
      html += '  <div class="forge-row" style="margin-top:10px;">';
      html += '    <button class="forge-btn forge-btn-primary" data-boss-prep="' + boss.id + '" style="flex:1;">+ Prepare</button>';
      html += '    <button class="forge-btn" data-boss-clear="' + boss.id + '" style="flex:1;">Mark Cleared</button>';
      html += '  </div>';
    } else {
      html += '  <div style="margin-top:8px;color:var(--ok);font-size:12px;">This trial has been overcome. Rewards claimed.</div>';
    }
    html += '  <button class="forge-btn forge-btn-ghost" data-boss-remove="' + boss.id + '" style="margin-top:6px;font-size:10px;">Remove</button>';
    html += '</div>';
    return html;
  }

  function render(state) {
    var sorted = state.bosses.slice().sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Boss Tower</div><div class="forge-screen-sub">Something waits at the top of every floor.</div></div>';

    if (!sorted.length) {
      html += '<div class="forge-panel"><div class="forge-empty">The tower stands quiet. Name your next trial below.</div></div>';
    } else {
      sorted.forEach(function (b) { html += bossCard(state, b); });
    }

    if (showAddForm) {
      html += '<div class="forge-panel forge-anim-in">';
      html += '  <div class="forge-panel-title">Add Boss</div>';
      html += '  <div class="forge-field"><label class="forge-label">Name</label><input class="forge-input" id="bNewName" maxlength="60" placeholder="e.g. Calculus Final" /></div>';
      html += '  <div class="forge-grid-2">';
      html += '    <div class="forge-field"><label class="forge-label">Date</label><input class="forge-input" id="bNewDate" type="date" /></div>';
      html += '    <div class="forge-field"><label class="forge-label">Recommended Level</label><input class="forge-input" id="bNewLevel" type="number" min="1" value="' + Forge.Engine.level(state.character.totalXP) + '" /></div>';
      html += '  </div>';
      html += '  <div class="forge-field"><label class="forge-label">Difficulty</label><select class="forge-select" id="bNewDiff"><option value="1">1 - Trivial</option><option value="2">2 - Easy</option><option value="3" selected>3 - Moderate</option><option value="4">4 - Hard</option><option value="5">5 - Brutal</option></select></div>';
      html += '  <div class="forge-row"><button class="forge-btn forge-btn-ghost" id="bNewCancel">Cancel</button><button class="forge-btn forge-btn-primary" id="bNewSubmit">Add</button></div>';
      html += '</div>';
    } else {
      html += '<button class="forge-btn forge-btn-block" id="bAddToggle">' + Forge.Icons.svg('plus') + ' Add Boss</button>';
    }

    html += '</div>';
    return html;
  }

  function mount(root, state) {
    root.querySelectorAll('[data-boss-prep]').forEach(function (el) {
      el.addEventListener('click', function () {
        Forge.Engine.logBossPrep(state, el.getAttribute('data-boss-prep'), 8);
        Forge.State.save();
        Forge.Sound.play('click');
        Forge.App.render();
      });
    });
    root.querySelectorAll('[data-boss-clear]').forEach(function (el) {
      el.addEventListener('click', function () {
        var result = Forge.Engine.clearBoss(state, el.getAttribute('data-boss-clear'));
        if (!result) return;
        Forge.State.save();
        Forge.Sound.play('achievement');
        Forge.UI.Toast.show('trophy', 'Boss Defeated', '+' + result.xpGained + ' XP');
        Object.keys(result.granted).forEach(function (matId) {
          var item = Forge.Data.getItem(matId);
          if (item) Forge.UI.Toast.show(item.icon, 'Loot Found', item.name + ' x' + result.granted[matId]);
        });
        if (result.leveledUp) Forge.UI.Toast.levelUpPopup(result.newLevel);
        (result.newAchievements || []).forEach(function (a) { Forge.UI.Toast.achievementPopup(a); });
        Forge.App.render();
      });
    });
    root.querySelectorAll('[data-boss-remove]').forEach(function (el) {
      el.addEventListener('click', function () {
        Forge.Engine.removeBoss(state, el.getAttribute('data-boss-remove'));
        Forge.State.save();
        Forge.App.render();
      });
    });
    var addToggle = root.querySelector('#bAddToggle');
    if (addToggle) addToggle.addEventListener('click', function () { showAddForm = true; Forge.App.render(); });
    var cancelBtn = root.querySelector('#bNewCancel');
    if (cancelBtn) cancelBtn.addEventListener('click', function () { showAddForm = false; Forge.App.render(); });
    var submitBtn = root.querySelector('#bNewSubmit');
    if (submitBtn) submitBtn.addEventListener('click', function () {
      var name = root.querySelector('#bNewName').value.trim();
      var date = root.querySelector('#bNewDate').value;
      if (!name || !date) return;
      Forge.Engine.addBoss(state, {
        name: name,
        date: date,
        recommendedLevel: parseInt(root.querySelector('#bNewLevel').value, 10) || 1,
        difficulty: parseInt(root.querySelector('#bNewDiff').value, 10) || 3
      });
      showAddForm = false;
      Forge.State.save();
      Forge.App.render();
    });
  }

  return { render: render, mount: mount };
})();

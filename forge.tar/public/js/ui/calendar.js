// Daily Forge 2.0 — Seasonal Events Calendar
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Calendar = (function () {
  var now = new Date();
  var viewYear = now.getFullYear();
  var viewMonth = now.getMonth();
  var DOW = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  var MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  function pad(n) { return String(n).padStart(2, '0'); }
  function dateStr(y, m, d) { return y + '-' + pad(m + 1) + '-' + pad(d); }

  function render(state) {
    var todayStr = Forge.State.todayStr();
    var firstDow = new Date(viewYear, viewMonth, 1).getDay();
    var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
    var eventsByDate = {};
    state.calendar.events.forEach(function (e) { (eventsByDate[e.date] = eventsByDate[e.date] || []).push(e); });

    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Calendar</div><div class="forge-screen-sub">Seasonal events &amp; milestones</div></div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-row" style="justify-content:space-between;margin-bottom:10px;">';
    html += '    <button class="forge-btn forge-btn-ghost" data-cal-nav="-1">' + Forge.Icons.svg('chevron').replace('<svg', '<svg style="transform:rotate(180deg)"') + '</button>';
    html += '    <span class="f-head" style="font-size:13px;letter-spacing:0.06em;">' + MONTH_NAMES[viewMonth] + ' ' + viewYear + '</span>';
    html += '    <button class="forge-btn forge-btn-ghost" data-cal-nav="1">' + Forge.Icons.svg('chevron') + '</button>';
    html += '  </div>';
    html += '  <div class="forge-cal-grid">';
    DOW.forEach(function (d) { html += '<div class="forge-cal-dow">' + d + '</div>'; });
    for (var i = 0; i < firstDow; i++) html += '<div class="forge-cal-cell empty"></div>';
    for (var d = 1; d <= daysInMonth; d++) {
      var ds = dateStr(viewYear, viewMonth, d);
      var hasEvent = !!eventsByDate[ds];
      html += '<div class="forge-cal-cell' + (ds === todayStr ? ' today' : '') + (hasEvent ? ' has-event' : '') + '" data-cal-day="' + ds + '">' + d + '</div>';
    }
    html += '  </div>';
    html += '</div>';

    var upcoming = state.calendar.events.filter(function (e) { return e.date >= todayStr; }).sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Upcoming Events</div>';
    if (!upcoming.length) {
      html += '<div class="forge-empty">Nothing scheduled. Tap a day to add Halloween, a con, a festival — anything worth marking.</div>';
    } else {
      html += '<div class="forge-col">';
      upcoming.forEach(function (e) {
        var typeInfo = Forge.Data.getEventType(e.type);
        var matNames = Object.keys(typeInfo.materials).map(function (id) {
          var item = Forge.Data.getItem(id);
          return (item ? item.name : id) + ' x' + typeInfo.materials[id];
        }).join(', ');
        var equipItem = typeInfo.equipment ? Forge.Data.getItem(typeInfo.equipment) : null;
        var rewardLine = matNames + (equipItem ? ' + ' + equipItem.name + ' (first time only)' : '');
        var statusText, statusColor;
        if (e.quest) {
          if (e.rewardState === 'granted') { statusText = 'Reward earned — quest completed.'; statusColor = 'var(--ok)'; }
          else { statusText = 'Tied quest: "' + e.quest.title + '". Reward: ' + rewardLine + '.'; statusColor = 'var(--gold)'; }
        } else {
          statusText = e.rewardState === 'granted' ? 'Reward claimed.' : 'Reward: ' + rewardLine + '.';
          statusColor = e.rewardState === 'granted' ? 'var(--ok)' : 'var(--muted)';
        }
        html += '<div style="padding:8px 10px;border:1px solid var(--line);border-radius:8px;">';
        html += '  <div class="forge-row" style="justify-content:space-between;">' +
          '<span class="forge-row">' + Forge.Icons.svg(e.icon) + '<span style="font-size:12.5px;">' + e.title + '</span></span>' +
          '<span class="forge-row"><span class="f-mono" style="font-size:11px;color:var(--muted);">' + e.date + '</span>' +
          '<button class="forge-btn-ghost" data-cal-remove="' + e.id + '" style="font-size:14px;">×</button></span></div>';
        html += '  <div style="font-size:10.5px;color:' + statusColor + ';margin-top:4px;">' + statusText + '</div>';
        html += '</div>';
      });
      html += '</div>';
    }
    html += '</div>';

    html += '</div>';
    return html;
  }

  function mount(root, state) {
    root.querySelectorAll('[data-cal-nav]').forEach(function (el) {
      el.addEventListener('click', function () {
        viewMonth += parseInt(el.getAttribute('data-cal-nav'), 10);
        if (viewMonth < 0) { viewMonth = 11; viewYear--; }
        if (viewMonth > 11) { viewMonth = 0; viewYear++; }
        Forge.App.render();
      });
    });
    root.querySelectorAll('[data-cal-day]').forEach(function (el) {
      el.addEventListener('click', function () { Forge.App.openEventModal(el.getAttribute('data-cal-day')); });
    });
    root.querySelectorAll('[data-cal-remove]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.stopPropagation();
        Forge.Engine.removeCalendarEvent(state, el.getAttribute('data-cal-remove'));
        Forge.State.save();
        Forge.App.render();
      });
    });
  }

  return { render: render, mount: mount };
})();

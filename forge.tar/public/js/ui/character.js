// Daily Forge 2.0 — Character sheet + equipment
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Character = (function () {
  var STAT_META = {
    strength: { label: 'Strength', icon: 'sword' },
    knowledge: { label: 'Knowledge', icon: 'book' },
    discipline: { label: 'Discipline', icon: 'shield' },
    vitality: { label: 'Vitality', icon: 'flame' },
    creativity: { label: 'Creativity', icon: 'crystal' },
    social: { label: 'Social', icon: 'accessory' }
  };

  var SLOT_ORDER = ['helmet', 'armor', 'accessory', 'pet', 'tool'];

  function statRow(state, key) {
    var meta = STAT_META[key];
    var base = state.character.stats[key] || 0;
    var bonus = Forge.Engine.statBonusFromEquipment(state, key);
    var max = Math.max(20, base + bonus + 5);
    var pct = Math.round(((base + bonus) / max) * 100);
    return '' +
      '<div class="forge-stat-row">' +
      '  <div class="forge-stat-top">' +
      '    <span class="forge-stat-name">' + Forge.Icons.svg(meta.icon) + meta.label + '</span>' +
      '    <span class="forge-stat-val">' + (base + bonus) + (bonus ? ' <span style="color:var(--ok)">(+' + bonus + ')</span>' : '') + '</span>' +
      '  </div>' +
      '  <div class="forge-bar-track forge-bar-sm"><div class="forge-bar-fill forge-bar-sm" style="width:' + pct + '%"></div></div>' +
      '</div>';
  }

  function slotCard(state, slot) {
    var itemId = state.equipment.slots[slot];
    var item = itemId ? Forge.Data.getItem(itemId) : null;
    return '' +
      '<div class="forge-equip-slot' + (item ? ' filled' : '') + '" data-equip-slot="' + slot + '">' +
      Forge.Icons.svg(item ? item.icon : slot) +
      '<div class="forge-equip-slot-label">' + slot + '</div>' +
      (item ? '<div class="forge-equip-slot-name">' + item.name + '</div>' : '') +
      '</div>';
  }

  function render(state) {
    var li = Forge.Engine.levelInfo(state.character.totalXP);
    var title = Forge.Engine.titleForLevel(li.level);

    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Character</div><div class="forge-screen-sub">' + title + '</div></div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-row" style="justify-content:space-between;">';
    html += '    <div><div class="f-display" style="font-size:18px;color:var(--white-hot);">' + state.character.name + '</div>';
    html += '    <div style="font-size:11px;color:var(--muted);">Class: ' + state.character.className + '</div></div>';
    html += '    <div style="text-align:right;"><div class="f-mono" style="font-size:22px;color:var(--accent);">LV ' + li.level + '</div>';
    html += '    <div style="font-size:10px;color:var(--muted);">' + state.character.totalXP + ' total XP</div></div>';
    html += '  </div>';
    html += '  <div style="margin-top:12px;">';
    html += '    <div class="forge-bar-label"><span>Progress</span><span class="f-mono">' + li.into + ' / ' + li.need + '</span></div>';
    html += '    <div class="forge-bar-track"><div class="forge-bar-fill" style="width:' + Math.round((li.into / li.need) * 100) + '%"></div></div>';
    html += '  </div>';
    html += '</div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Stats</div>';
    Object.keys(STAT_META).forEach(function (k) { html += statRow(state, k); });
    html += '</div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Equipment</div>';
    html += '  <div class="forge-grid-3">';
    SLOT_ORDER.forEach(function (slot) { html += slotCard(state, slot); });
    html += '  </div>';
    html += '</div>';

    html += '</div>';
    return html;
  }

  function mount(root, state) {
    root.querySelectorAll('[data-equip-slot]').forEach(function (el) {
      el.addEventListener('click', function () { Forge.App.openEquipModal(el.getAttribute('data-equip-slot')); });
    });
  }

  return { render: render, mount: mount, SLOT_ORDER: SLOT_ORDER };
})();

// Daily Forge 2.0 — Home screen
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Home = (function () {
  var STREAK_MILESTONES = [7, 14, 30, 60, 100, 200, 365];

  function companionCategory(state, temperPct) {
    if ((state.flags.gapDays || 0) > 1) return 'returningAfterGap';
    if (STREAK_MILESTONES.indexOf(state.character.streak) !== -1) return 'streakMilestone';
    if (temperPct >= 75) return 'highTemper';
    if (temperPct < 30) return 'lowTemper';
    var hour = new Date().getHours();
    if (hour < 12) return 'greetingMorning';
    if (hour < 18) return 'greetingAfternoon';
    return 'greetingEvening';
  }

  function questRow(q, isMain) {
    var tag = q.time || Forge.Data.AREA_NAME(q.area);
    return '' +
      '<div class="forge-quest' + (q.done ? ' done' : '') + (isMain ? ' main' : '') + '" data-quest-toggle="' + q.id + '">' +
      '  <div class="forge-quest-check">' + Forge.Icons.svg('check') + '</div>' +
      '  <div class="forge-quest-body">' +
      '    <div class="forge-quest-top"><span class="forge-quest-title">' + q.title + '</span><span class="forge-quest-area">' + tag + '</span></div>' +
      '    <div class="forge-quest-flavor">' + q.flavor + '</div>' +
      '    <div class="forge-quest-xp">' + (q.done ? 'CLAIMED' : '+' + q.xp + ' XP') + '</div>' +
      '  </div>' +
      '  <div class="forge-quest-actions">' +
      '    <button class="forge-quest-editbtn" data-quest-edit="' + q.id + '" aria-label="Edit quest">' + Forge.Icons.svg('edit') + '</button>' +
      '  </div>' +
      '</div>';
  }

  function render(state) {
    var li = Forge.Engine.levelInfo(state.character.totalXP);
    var title = Forge.Engine.titleForLevel(li.level);
    var temperPct = state.character.temper;
    var status = Forge.Engine.computeStatus(state);
    var todays = state.quests.instances.filter(function (q) { return q.date === state.today.date; });
    var dailyQuests = todays.filter(function (q) { return q.type === 'daily'; });
    var dailyDoneCount = dailyQuests.filter(function (q) { return q.done; }).length;
    var sideQuests = todays.filter(function (q) { return q.type === 'side'; }).slice(0, 4);
    var upcoming = Forge.Engine.nextUpcomingEvent(state);
    var companionLine = Forge.Data.pickLine(companionCategory(state, temperPct));

    var html = '<div class="forge-screen">';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-row" style="justify-content:space-between;">';
    html += '    <div><div class="f-display" style="font-size:19px;color:var(--white-hot);">' + state.character.name + '</div>';
    html += '    <div style="font-size:11.5px;color:var(--accent);letter-spacing:0.05em;">' + title + ' &middot; Level ' + li.level + '</div></div>';
    html += '  </div>';
    html += '  <div style="margin-top:14px;">';
    html += '    <div class="forge-bar-label"><span>Temper Gauge</span><span class="f-mono">' + temperPct + '%</span></div>';
    html += '    <div class="forge-bar-track"><div class="forge-bar-fill" style="width:' + temperPct + '%;background:' + Forge.Engine.temperColor(temperPct) + '"></div></div>';
    html += '  </div>';
    html += '  <div style="margin-top:10px;">';
    html += '    <div class="forge-bar-label"><span>XP to Level ' + (li.level + 1) + '</span><span class="f-mono">' + li.into + ' / ' + li.need + '</span></div>';
    html += '    <div class="forge-bar-track forge-bar-sm"><div class="forge-bar-fill forge-bar-sm" style="width:' + Math.round((li.into / li.need) * 100) + '%"></div></div>';
    html += '  </div>';
    html += '</div>';

    if (upcoming) {
      var isEventToday = upcoming.daysAway === 0;
      var ev = upcoming.event;
      html += '<div class="forge-panel forge-anim-in" style="padding:12px 14px;">';
      html += '  <div class="forge-row" style="align-items:center;gap:10px;">';
      html += Forge.Icons.svg(upcoming.typeInfo.icon, '').replace('<svg', '<svg style="width:18px;height:18px;color:var(--accent);flex-shrink:0;"');
      html += '<span style="font-size:12.5px;color:var(--text-dim);">' + (isEventToday ? '' : Forge.Data.pickLine('bossUpcoming') + ' ') + '<b style="color:var(--text)">' + ev.title + '</b> ' + (isEventToday ? 'is today.' : 'in ' + upcoming.daysAway + ' day' + (upcoming.daysAway === 1 ? '' : 's') + '.') + '</span>';
      html += '  </div>';
      if (isEventToday && ev.quest) {
        if (ev.rewardState === 'granted') {
          html += '<div style="font-size:11px;color:var(--ok);margin-top:6px;">"' + ev.quest.title + '" is done — the forge left something for you in your Inventory.</div>';
        } else {
          html += '<div style="font-size:11px;color:var(--gold);margin-top:6px;">Complete "' + ev.quest.title + '" today to earn the reward — find it on the Quests board.</div>';
        }
      } else if (isEventToday && !ev.quest) {
        html += '<div style="font-size:11px;color:var(--ok);margin-top:6px;">The forge left something for you — check your Inventory.</div>';
      } else if (!isEventToday) {
        var matNames = Object.keys(upcoming.typeInfo.materials).map(function (id) {
          var item = Forge.Data.getItem(id);
          return (item ? item.name : id) + ' x' + upcoming.typeInfo.materials[id];
        }).join(', ');
        var upcomingEquipItem = upcoming.typeInfo.equipment ? Forge.Data.getItem(upcoming.typeInfo.equipment) : null;
        html += '<div style="font-size:11px;color:var(--muted);margin-top:6px;">Reward: ' + matNames + (upcomingEquipItem ? ' + ' + upcomingEquipItem.name + ' (first time only)' : '') + (ev.quest ? ' (requires completing "' + ev.quest.title + '" that day)' : '') + '.</div>';
      }
      html += '</div>';
    }

    html += '<div class="forge-companion forge-anim-in">';
    html += '  <div class="forge-companion-orb"></div>';
    html += '  <div><div class="forge-companion-name">' + Forge.Data.COMPANION_NAME + '</div><div class="forge-companion-text">"' + companionLine + '"</div></div>';
    html += '</div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Main Quest</div>';
    html += '  <div style="margin-bottom:10px;">';
    html += '    <div class="f-display" style="font-size:15px;color:var(--white-hot);">Survive the Day</div>';
    html += '    <div style="font-size:11px;color:var(--muted);margin-top:2px;" class="f-mono">' + dailyDoneCount + ' / ' + dailyQuests.length + ' objectives complete</div>';
    html += '  </div>';
    if (!dailyQuests.length) {
      html += '<div class="forge-empty">Nothing scheduled today.</div>';
    } else {
      html += '<div class="forge-col">';
      dailyQuests.forEach(function (q) { html += questRow(q, true); });
      html += '</div>';
    }
    html += '</div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Side Quests</div>';
    if (!sideQuests.length) {
      html += '<div class="forge-empty">No side quests yet. Add one from the Quests board.</div>';
    } else {
      html += '<div class="forge-col">';
      sideQuests.forEach(function (q) { html += questRow(q, false); });
      html += '</div>';
    }
    html += '</div>';

    if (status.buffs.length || status.debuffs.length) {
      html += '<div class="forge-panel forge-anim-in">';
      html += '  <div class="forge-panel-title">Condition</div>';
      html += '  <div class="forge-row" style="flex-wrap:wrap;">';
      status.buffs.forEach(function (b) { html += '<span class="forge-chip buff" title="' + b.desc + '">' + Forge.Icons.svg(b.icon) + b.name + '</span>'; });
      status.debuffs.forEach(function (b) { html += '<span class="forge-chip debuff" title="' + b.desc + '">' + Forge.Icons.svg(b.icon) + b.name + '</span>'; });
      html += '  </div></div>';
    }

    html += '<button class="forge-btn forge-btn-primary forge-btn-block" data-open-report="1" style="padding:14px;">Continue</button>';

    html += '</div>';
    return html;
  }

  function mount(root, state) {
    root.querySelectorAll('[data-quest-toggle]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        if (e.target.closest('[data-quest-edit]')) return;
        Forge.App.toggleQuest(el.getAttribute('data-quest-toggle'), el);
      });
    });
    root.querySelectorAll('[data-quest-edit]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.stopPropagation();
        var q = state.quests.instances.find(function (x) { return x.id === el.getAttribute('data-quest-edit'); });
        if (q) Forge.App.openEditQuestModal(q);
      });
    });
    var reportBtn = root.querySelector('[data-open-report]');
    if (reportBtn) reportBtn.addEventListener('click', function () { Forge.App.openReportModal(); });
  }

  return { render: render, mount: mount };
})();

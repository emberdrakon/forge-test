// Daily Forge 2.0 — Inventory + Crafting
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Inventory = (function () {
  var tab = 'materials';
  var TABS = [
    { id: 'materials', label: 'Materials' },
    { id: 'consumables', label: 'Consumables' },
    { id: 'equipment', label: 'Equipment' },
    { id: 'crafting', label: 'Crafting' }
  ];

  function itemCard(item, qty, opts) {
    opts = opts || {};
    return '' +
      '<div class="forge-item' + (item.rarity === 'rare' ? ' rare' : '') + '" ' + (opts.action ? 'data-item-action="' + opts.action + '" data-item-id="' + item.id + '"' : '') + ' title="' + (item.flavor || '') + '">' +
      (qty !== undefined ? '<div class="forge-item-count">' + qty + '</div>' : '') +
      Forge.Icons.svg(item.icon, 'forge-item-icon') +
      '<div class="forge-item-name">' + item.name + '</div>' +
      '</div>';
  }

  function renderMaterials(state) {
    var held = Forge.Data.MATERIALS.filter(function (m) { return (state.inventory.materials[m.id] || 0) > 0; });
    if (!held.length) return '<div class="forge-empty">No materials gathered yet. Complete quests to find loot.</div>';
    return '<div class="forge-grid-4">' + held.map(function (m) { return itemCard(m, state.inventory.materials[m.id]); }).join('') + '</div>';
  }

  function renderConsumables(state) {
    var held = Forge.Data.CONSUMABLES.filter(function (m) { return (state.inventory.consumables[m.id] || 0) > 0; });
    if (!held.length) return '<div class="forge-empty">No consumables yet. Craft or find them.</div>';
    return '<div class="forge-grid-4">' + held.map(function (m) { return itemCard(m, state.inventory.consumables[m.id], { action: 'use' }); }).join('') + '</div>';
  }

  function renderEquipment(state) {
    var owned = state.equipment.owned.filter(function (id) { return !!Forge.Data.getItem(id); });
    if (!owned.length) return '<div class="forge-empty">No equipment owned yet. Craft it or find it as rare loot.</div>';
    return '<div class="forge-grid-4">' + owned.map(function (id) {
      var item = Forge.Data.getItem(id);
      var equipped = state.equipment.slots[item.slot] === id;
      var card = itemCard(item, undefined, { action: 'equip' });
      if (equipped) card = card.replace('class="forge-item', 'class="forge-item equipped');
      return card;
    }).join('') + '</div>';
  }

  function renderCrafting(state) {
    var html = '<div class="forge-col">';
    Forge.Data.RECIPES.forEach(function (r) {
      var owned = r.cosmeticId ? state.crafting.unlockedCosmetics.indexOf(r.cosmeticId) !== -1 : state.equipment.owned.indexOf(r.itemId) !== -1;
      var afford = Object.keys(r.cost).every(function (id) { return (state.inventory.materials[id] || 0) >= r.cost[id]; });
      var costStr = Object.keys(r.cost).map(function (id) {
        var have = state.inventory.materials[id] || 0;
        var need = r.cost[id];
        var mat = Forge.Data.getItem(id);
        return '<span style="color:' + (have >= need ? 'var(--ok)' : 'var(--bad)') + '">' + mat.name + ' ' + have + '/' + need + '</span>';
      }).join(' &middot; ');
      html += '<div class="forge-row" style="justify-content:space-between;padding:12px;border:1px solid var(--line);border-radius:8px;background:var(--panel-2);">';
      html += '  <div class="forge-row">' + Forge.Icons.svg(r.icon, 'forge-item-icon') + '<div><div style="font-size:13px;font-weight:600;">' + r.name + '</div><div style="font-size:10.5px;color:var(--muted);">' + costStr + '</div></div></div>';
      html += owned ? '<span class="f-mono" style="font-size:10.5px;color:var(--ok);">OWNED</span>' :
        '<button class="forge-btn' + (afford ? ' forge-btn-primary' : '') + '" data-craft="' + r.id + '"' + (afford ? '' : ' disabled') + ' style="font-size:10px;padding:8px 12px;">Craft</button>';
      html += '</div>';
    });
    html += '</div>';
    return html;
  }

  function render(state) {
    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Inventory</div></div>';
    html += '<div class="forge-tabs">';
    TABS.forEach(function (t) { html += '<button class="forge-tab' + (tab === t.id ? ' active' : '') + '" data-inv-tab="' + t.id + '">' + t.label + '</button>'; });
    html += '</div>';
    html += '<div class="forge-panel forge-anim-in">';
    if (tab === 'materials') html += renderMaterials(state);
    if (tab === 'consumables') html += renderConsumables(state);
    if (tab === 'equipment') html += renderEquipment(state);
    if (tab === 'crafting') html += renderCrafting(state);
    html += '</div>';
    html += '</div>';
    return html;
  }

  function mount(root, state) {
    root.querySelectorAll('[data-inv-tab]').forEach(function (el) {
      el.addEventListener('click', function () { tab = el.getAttribute('data-inv-tab'); Forge.App.render(); });
    });
    root.querySelectorAll('[data-item-action="use"]').forEach(function (el) {
      el.addEventListener('click', function () {
        var ok = Forge.Engine.applyConsumable(state, el.getAttribute('data-item-id'));
        if (ok) { Forge.State.save(); Forge.Sound.play('loot'); Forge.App.render(); }
      });
    });
    root.querySelectorAll('[data-item-action="equip"]').forEach(function (el) {
      el.addEventListener('click', function () {
        var item = Forge.Data.getItem(el.getAttribute('data-item-id'));
        Forge.Engine.equipItem(state, item.id);
        Forge.State.save();
        Forge.Sound.play('click');
        Forge.App.render();
      });
    });
    root.querySelectorAll('[data-craft]').forEach(function (el) {
      el.addEventListener('click', function () {
        var res = Forge.Engine.craftRecipe(state, el.getAttribute('data-craft'));
        if (res.ok) {
          Forge.State.save();
          Forge.Sound.play('craft');
          Forge.UI.Toast.show(res.recipe.icon, 'Crafted', res.recipe.name);
          (res.newAchievements || []).forEach(function (a) { Forge.UI.Toast.achievementPopup(a); });
          Forge.App.render();
        }
      });
    });
  }

  return { render: render, mount: mount };
})();

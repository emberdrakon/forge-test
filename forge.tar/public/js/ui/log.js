// Daily Forge 2.0 — Forge Log: freeform journal entries, timestamped by creation
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Log = (function () {
  var showAddForm = false;
  var confirmingRemoveId = null;

  function escapeHtml(s) {
    return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function formatTimestamp(iso) {
    var d = new Date(iso);
    var dateStr = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
    var timeStr = d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    return dateStr + ' · ' + timeStr;
  }

  function entryCard(entry, confirming) {
    var actionsHtml = confirming ?
      '<span class="forge-row" style="gap:6px;">' +
      '  <button class="forge-btn forge-btn-ghost" data-log-cancel-remove="' + entry.id + '" style="font-size:10.5px;padding:3px 9px;">Cancel</button>' +
      '  <button class="forge-btn forge-btn-danger" data-log-confirm-remove="' + entry.id + '" style="font-size:10.5px;padding:3px 9px;">Delete</button>' +
      '</span>' :
      '<button class="forge-quest-remove" data-log-remove="' + entry.id + '" aria-label="Delete entry">×</button>';

    return '' +
      '<div class="forge-panel forge-anim-in" style="padding:14px;">' +
      '  <div class="forge-row" style="justify-content:space-between;align-items:flex-start;">' +
      '    <span class="f-mono" style="font-size:10.5px;color:var(--muted);letter-spacing:0.04em;">' + formatTimestamp(entry.createdAt) + '</span>' +
      '    ' + actionsHtml +
      '  </div>' +
      (entry.title ? '  <div style="margin-top:6px;font-size:14px;font-weight:600;color:var(--white-hot);">' + escapeHtml(entry.title) + '</div>' : '') +
      '  <div style="margin-top:6px;font-size:13px;color:var(--text);white-space:pre-wrap;">' + escapeHtml(entry.text) + '</div>' +
      (confirming ? '  <div style="margin-top:8px;font-size:11px;color:var(--bad);">Delete this entry? This can’t be undone.</div>' : '') +
      '</div>';
  }

  function render(state) {
    var entries = (state.logs || []).slice().sort(function (a, b) { return b.createdAt.localeCompare(a.createdAt); });

    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Forge Log</div><div class="forge-screen-sub">' + entries.length + ' ' + (entries.length === 1 ? 'entry' : 'entries') + '</div></div>';

    html += '<div class="forge-panel forge-anim-in" style="border-color:var(--accent-dim);">';
    html += '  <div class="forge-panel-title">New Entry</div>';
    if (showAddForm) {
      html += '  <div class="forge-field"><label class="forge-label">Title (optional)</label><input class="forge-input" id="logNewTitle" maxlength="80" placeholder="e.g. Rough day at the dungeon" /></div>';
      html += '  <div class="forge-field"><textarea class="forge-textarea" id="logNewText" maxlength="2000" rows="4" placeholder="Write what’s on your mind..."></textarea></div>';
      html += '  <div class="forge-grid-2">';
      html += '    <button class="forge-btn forge-btn-ghost forge-btn-block" id="logNewCancel" style="padding:13px;">Cancel</button>';
      html += '    <button class="forge-btn forge-btn-primary forge-btn-block" id="logNewSubmit" style="padding:13px;">Save Entry</button>';
      html += '  </div>';
    } else {
      html += '  <button class="forge-btn forge-btn-primary forge-btn-block" id="logAddToggle" style="padding:14px;">' + Forge.Icons.svg('plus') + ' New Log Entry</button>';
    }
    html += '</div>';

    html += '<div class="forge-col">';
    html += entries.length ? entries.map(function (e) { return entryCard(e, confirmingRemoveId === e.id); }).join('') : '<div class="forge-empty">No entries yet. Write your first one above.</div>';
    html += '</div>';

    html += '</div>';
    return html;
  }

  function mount(root, state) {
    var addToggle = root.querySelector('#logAddToggle');
    if (addToggle) addToggle.addEventListener('click', function () { showAddForm = true; Forge.App.render(); });
    var cancelBtn = root.querySelector('#logNewCancel');
    if (cancelBtn) cancelBtn.addEventListener('click', function () { showAddForm = false; Forge.App.render(); });
    var submitBtn = root.querySelector('#logNewSubmit');
    if (submitBtn) submitBtn.addEventListener('click', function () {
      var title = root.querySelector('#logNewTitle').value.trim();
      var text = root.querySelector('#logNewText').value.trim();
      if (!text) return;
      Forge.Engine.addLogEntry(state, title, text);
      showAddForm = false;
      Forge.State.save();
      Forge.App.render();
    });
    root.querySelectorAll('[data-log-remove]').forEach(function (el) {
      el.addEventListener('click', function () {
        confirmingRemoveId = el.getAttribute('data-log-remove');
        Forge.App.render();
      });
    });
    root.querySelectorAll('[data-log-cancel-remove]').forEach(function (el) {
      el.addEventListener('click', function () {
        confirmingRemoveId = null;
        Forge.App.render();
      });
    });
    root.querySelectorAll('[data-log-confirm-remove]').forEach(function (el) {
      el.addEventListener('click', function () {
        Forge.Engine.removeLogEntry(state, el.getAttribute('data-log-confirm-remove'));
        confirmingRemoveId = null;
        Forge.State.save();
        Forge.App.render();
      });
    });
  }

  return { render: render, mount: mount };
})();

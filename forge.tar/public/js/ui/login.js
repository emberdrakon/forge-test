// Daily Forge 2.0 — sign-in gate, shown before Forge.App.boot() when there's no authenticated user
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Login = (function () {
  function render() {
    var html = '<div class="forge-screen" style="justify-content:center;align-items:center;min-height:70vh;">';
    html += '  <div class="forge-panel forge-anim-in" style="text-align:center;max-width:320px;margin:auto;">';
    html += '    <div style="margin-bottom:8px;">' + Forge.Icons.svg('flame') + '</div>';
    html += '    <div class="forge-screen-title" style="margin-bottom:4px;">The Forge</div>';
    html += '    <div style="font-size:12.5px;color:var(--muted);margin-bottom:20px;">Sign in to keep your progress synced.</div>';
    html += '    <button class="forge-btn forge-btn-primary forge-btn-block" id="loginGoogle">Sign in with Google</button>';
    html += '  </div>';
    html += '</div>';
    return html;
  }

  function mount(root) {
    var btn = root.querySelector('#loginGoogle');
    if (btn) btn.addEventListener('click', function () { Forge.Auth.signIn(); });
  }

  return { render: render, mount: mount };
})();

// Daily Forge 2.0 — World Map
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Map = (function () {
  var selectedArea = null;

  function render(state) {
    var unlocked = Forge.Engine.unlockedAreas(state);
    var current = state.position.areaId;
    if (!selectedArea) selectedArea = current;

    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">World Map</div><div class="forge-screen-sub">' + Forge.Data.AREA_NAME(current) + '</div></div>';

    html += '<div class="forge-map-wrap forge-anim-in">';
    html += '<svg class="forge-map-svg" viewBox="0 0 100 100" preserveAspectRatio="none">';
    Forge.Data.WORLD_PATHS.forEach(function (pair) {
      var a = Forge.Data.AREAS.find(function (x) { return x.id === pair[0]; });
      var b = Forge.Data.AREAS.find(function (x) { return x.id === pair[1]; });
      if (!a || !b) return;
      html += '<line x1="' + a.x + '" y1="' + a.y + '" x2="' + b.x + '" y2="' + b.y + '" class="forge-map-path" />';
    });
    html += '</svg>';

    Forge.Data.AREAS.forEach(function (area) {
      var isUnlocked = unlocked.indexOf(area.id) !== -1;
      var isCurrent = area.id === current;
      html += '<div class="forge-map-node' + (isUnlocked ? ' unlocked' : ' locked') + (isCurrent ? ' current' : '') +
        '" style="left:' + area.x + '%;top:' + area.y + '%;" data-map-node="' + area.id + '" data-unlocked="' + isUnlocked + '">' +
        '<div class="forge-map-node-dot"></div><div class="forge-map-node-label">' + area.name + '</div></div>';
    });

    var curArea = Forge.Data.AREAS.find(function (a) { return a.id === current; });
    if (curArea) {
      html += '<div class="forge-map-player" style="left:' + curArea.x + '%;top:' + curArea.y + '%;">' + Forge.Icons.svg('footprint') + '</div>';
    }
    html += '</div>';

    var shown = Forge.Data.AREAS.find(function (a) { return a.id === selectedArea; }) || curArea;
    if (shown) {
      var isUnlockedShown = unlocked.indexOf(shown.id) !== -1;
      html += '<div class="forge-panel forge-anim-in">';
      html += '  <div class="forge-panel-title">' + shown.name + '</div>';
      if (!isUnlockedShown) {
        html += '<div class="forge-empty">Locked until Level ' + shown.unlockLevel + '.</div>';
      } else {
        html += '<div style="font-size:12.5px;color:var(--text-dim);margin-bottom:10px;">' + shown.desc + '</div>';
        var questsHere = state.quests.instances.filter(function (q) { return q.date === state.today.date && q.area === shown.id; });
        if (questsHere.length) {
          html += '<div class="forge-col">';
          questsHere.forEach(function (q) {
            html += '<div class="forge-row" style="justify-content:space-between;padding:8px 10px;border:1px solid var(--line);border-radius:8px;">' +
              '<span style="font-size:12px;' + (q.done ? 'color:var(--muted);text-decoration:line-through;' : '') + '">' + q.title + '</span>' +
              '<span class="f-mono" style="font-size:11px;color:var(--accent);">' + (q.done ? 'DONE' : '+' + q.xp) + '</span></div>';
          });
          html += '</div>';
        } else {
          html += '<div class="forge-empty">No quests tied here today.</div>';
        }
        if (shown.id !== current) {
          html += '<button class="forge-btn forge-btn-primary forge-btn-block" style="margin-top:10px;" data-travel-to="' + shown.id + '">Travel Here</button>';
        }
      }
      html += '</div>';
    }

    html += '</div>';
    return html;
  }

  function mount(root, state) {
    root.querySelectorAll('[data-map-node]').forEach(function (el) {
      el.addEventListener('click', function () {
        selectedArea = el.getAttribute('data-map-node');
        Forge.App.render();
      });
    });
    var travelBtn = root.querySelector('[data-travel-to]');
    if (travelBtn) travelBtn.addEventListener('click', function () {
      var id = travelBtn.getAttribute('data-travel-to');
      state.position.areaId = id;
      Forge.Engine.visitArea(state, id);
      Forge.State.save();
      Forge.Sound.play('click');
      Forge.App.render();
    });
  }

  return { render: render, mount: mount };
})();

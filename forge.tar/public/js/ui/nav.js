// Daily Forge 2.0 — navigation: bottom tab bar + overflow drawer
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Nav = (function () {
  var current = 'home';
  var drawerOpen = false;

  var PRIMARY = [
    { id: 'home', label: 'Home', icon: 'home' },
    { id: 'character', label: 'Character', icon: 'character' },
    { id: 'map', label: 'World', icon: 'world' },
    { id: 'quests', label: 'Quests', icon: 'quests' },
    { id: 'inventory', label: 'Inventory', icon: 'bag' },
    { id: 'log', label: 'Log', icon: 'book' }
  ];

  var SECONDARY = [
    { id: 'skills', label: 'Skill Trees', icon: 'skills' },
    { id: 'bosses', label: 'Boss Tower', icon: 'boss' },
    { id: 'achievements', label: 'Achievements', icon: 'trophy' },
    { id: 'calendar', label: 'Calendar', icon: 'calendar' },
    { id: 'settings', label: 'Settings', icon: 'settings' }
  ];

  function go(id) {
    current = id;
    drawerOpen = false;
    Forge.Sound.play('click');
    Forge.App.render();
    window.scrollTo(0, 0);
  }

  function toggleDrawer(force) {
    drawerOpen = (force !== undefined) ? force : !drawerOpen;
    Forge.App.render();
  }

  function renderTopbar(state) {
    var lvl = Forge.Engine.level(state.character.totalXP);
    var streak = state.character.streak || 0;
    return '' +
      '<div class="forge-topbar">' +
      '  <div class="forge-brand">' + Forge.Icons.svg('flame', 'brand-flame') + 'THE FORGE</div>' +
      '  <div class="forge-topbar-right">' +
      '    <span class="forge-streak' + (streak === 0 ? ' zero' : '') + '">' + Forge.Icons.svg('flame') + '<span class="f-mono">' + streak + '</span></span>' +
      '    <span class="f-mono" style="font-size:11px;color:var(--muted)">LV <b style="color:var(--accent)">' + lvl + '</b></span>' +
      '    <button class="forge-menu-btn" data-nav-menu="1" aria-label="Menu">' + Forge.Icons.svg('menu') + '</button>' +
      '  </div>' +
      '</div>';
  }

  function renderBottomNav() {
    var html = '<div class="forge-nav">';
    PRIMARY.forEach(function (s) {
      html += '<button class="forge-nav-btn' + (current === s.id ? ' active' : '') + '" data-nav-go="' + s.id + '">' +
        Forge.Icons.svg(s.icon) + '<span>' + s.label + '</span></button>';
    });
    html += '</div>';
    return html;
  }

  function renderDrawer(state) {
    if (!drawerOpen) return '';
    var html = '<div class="forge-overlay" data-nav-overlay="1"><div class="forge-drawer" data-nav-drawer="1">';
    html += '<div class="forge-drawer-title">Codex</div>';
    SECONDARY.forEach(function (s) {
      html += '<button class="forge-drawer-item" data-nav-go="' + s.id + '">' + Forge.Icons.svg(s.icon) + '<span>' + s.label + '</span></button>';
      if (s.id === 'settings') {
        html += '<button class="forge-drawer-item" data-nav-signout="1">' + Forge.Icons.svg('signout') + '<span>Sign Out</span></button>';
      }
    });
    html += '</div></div>';
    return html;
  }

  function bindEvents(root) {
    root.querySelectorAll('[data-nav-go]').forEach(function (btn) {
      btn.addEventListener('click', function () { go(btn.getAttribute('data-nav-go')); });
    });
    var menuBtn = root.querySelector('[data-nav-menu]');
    if (menuBtn) menuBtn.addEventListener('click', function () { toggleDrawer(true); });
    var overlay = root.querySelector('[data-nav-overlay]');
    if (overlay) overlay.addEventListener('click', function (e) { if (e.target === overlay) toggleDrawer(false); });
    var signOutBtn = root.querySelector('[data-nav-signout]');
    if (signOutBtn) signOutBtn.addEventListener('click', function () {
      Forge.State.flush().then(function () {
        Forge.State.reset();
        Forge.Auth.signOut();
      });
    });
  }

  function getCurrent() { return current; }
  function isPrimary(id) { return PRIMARY.some(function (s) { return s.id === id; }); }
  function allScreens() { return PRIMARY.concat(SECONDARY); }

  return {
    go: go, toggleDrawer: toggleDrawer,
    renderTopbar: renderTopbar, renderBottomNav: renderBottomNav, renderDrawer: renderDrawer,
    bindEvents: bindEvents, getCurrent: getCurrent, isPrimary: isPrimary, allScreens: allScreens
  };
})();

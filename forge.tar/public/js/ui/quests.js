// Daily Forge 2.0 — Quest board (grouped by time-of-day section, plus custom)
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Quests = (function () {
  var showAddForm = false;

  function questCard(q, state) {
    var tag = q.time || Forge.Data.AREA_NAME(q.area);
    var isDaily = q.type === 'daily';
    return '' +
      '<div class="forge-quest' + (q.done ? ' done' : '') + (isDaily ? ' main' : '') + '" data-quest-toggle="' + q.id + '">' +
      '  <div class="forge-quest-check">' + Forge.Icons.svg('check') + '</div>' +
      '  <div class="forge-quest-body">' +
      '    <div class="forge-quest-top"><span class="forge-quest-title">' + q.title + '</span><span class="forge-quest-area">' + tag + '</span></div>' +
      '    <div class="forge-quest-flavor">' + (q.flavor || '<span style="opacity:0.6">No description.</span>') + '</div>' +
      '    <div class="forge-quest-xp">' + (q.done ? 'CLAIMED' : '+' + q.xp + ' XP') + '</div>' +
      '  </div>' +
      '  <div class="forge-quest-actions">' +
      '    <button class="forge-quest-editbtn" data-quest-edit="' + q.id + '" aria-label="Edit quest">' + Forge.Icons.svg('edit') + '</button>' +
      (q.custom ? '<button class="forge-quest-remove" data-quest-remove="' + q.id + '" aria-label="Remove">×</button>' : '') +
      '  </div>' +
      '</div>';
  }

  function areaOptions(selected) {
    return Forge.Data.AREAS.map(function (a) {
      return '<option value="' + a.id + '"' + (a.id === selected ? ' selected' : '') + '>' + a.name + '</option>';
    }).join('');
  }

  function statOptions() {
    return ['strength', 'knowledge', 'discipline', 'vitality', 'creativity', 'social'].map(function (s) {
      return '<option value="' + s + '">' + s.charAt(0).toUpperCase() + s.slice(1) + '</option>';
    }).join('');
  }

  function render(state) {
    var todays = state.quests.instances.filter(function (q) { return q.date === state.today.date; });
    var custom = todays.filter(function (q) { return q.custom; });

    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Quest Board</div><div class="forge-screen-sub">' + Forge.Engine.completion(state) + '% today</div></div>';

    Forge.Data.SECTION_ORDER.forEach(function (section) {
      var inSection = todays.filter(function (q) { return !q.custom && q.section === section; });
      if (!inSection.length) return;
      html += '<div class="forge-panel forge-anim-in"><div class="forge-panel-title">' + section + '</div><div class="forge-col">';
      html += inSection.map(function (q) { return questCard(q, state); }).join('');
      html += '</div></div>';
    });

    html += '<div class="forge-panel forge-anim-in"><div class="forge-panel-title">Custom Quests</div><div class="forge-col">';
    html += custom.map(function (q) { return questCard(q, state); }).join('') || '<div class="forge-empty">No custom quests yet.</div>';
    html += '</div></div>';

    html += '<div class="forge-panel forge-anim-in" style="border-color:var(--accent-dim);">';
    html += '  <div class="forge-panel-title">Add a New Quest</div>';
    if (showAddForm) {
      html += '  <div class="forge-field"><label class="forge-label">Quest Name</label><input class="forge-input" id="qNewTitle" maxlength="60" placeholder="e.g. Practice Spanish" /></div>';
      html += '  <div class="forge-field"><label class="forge-label">Description</label><textarea class="forge-textarea" id="qNewFlavor" maxlength="200" placeholder="Optional flavor text"></textarea></div>';
      html += '  <div class="forge-grid-2">';
      html += '    <div class="forge-field"><label class="forge-label">Area</label><select class="forge-select" id="qNewArea">' + areaOptions('homeVillage') + '</select></div>';
      html += '    <div class="forge-field"><label class="forge-label">Stat</label><select class="forge-select" id="qNewStat">' + statOptions() + '</select></div>';
      html += '  </div>';
      html += '  <div class="forge-grid-2">';
      html += '    <div class="forge-field"><label class="forge-label">Time (optional)</label><input class="forge-input" id="qNewTime" type="time" /></div>';
      html += '    <div class="forge-field"><label class="forge-label">XP Reward</label><input class="forge-input" id="qNewXp" type="number" min="1" max="500" value="15" /></div>';
      html += '  </div>';
      html += '  <label class="forge-checkline"><input type="checkbox" id="qNewRepeat" /> Repeat every day</label>';
      html += '  <div class="forge-grid-2" style="margin-top:14px;">';
      html += '    <button class="forge-btn forge-btn-ghost forge-btn-block" id="qNewCancel" style="padding:13px;">Cancel</button>';
      html += '    <button class="forge-btn forge-btn-primary forge-btn-block" id="qNewSubmit" style="padding:13px;">Save Quest</button>';
      html += '  </div>';
    } else {
      html += '  <button class="forge-btn forge-btn-primary forge-btn-block" id="qAddToggle" style="padding:14px;">' + Forge.Icons.svg('plus') + ' Add Custom Quest</button>';
    }
    html += '</div>';

    html += '</div>';
    return html;
  }

  function mount(root, state) {
    root.querySelectorAll('[data-quest-toggle]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        if (e.target.closest('[data-quest-remove], [data-quest-edit]')) return;
        Forge.App.toggleQuest(el.getAttribute('data-quest-toggle'), el);
      });
    });
    root.querySelectorAll('[data-quest-remove]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.stopPropagation();
        Forge.Engine.removeCustomQuest(state, el.getAttribute('data-quest-remove'));
        Forge.State.save();
        Forge.App.render();
      });
    });
    root.querySelectorAll('[data-quest-edit]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.stopPropagation();
        var q = state.quests.instances.find(function (x) { return x.id === el.getAttribute('data-quest-edit'); });
        if (q) Forge.App.openEditQuestModal(q);
      });
    });
    var addToggle = root.querySelector('#qAddToggle');
    if (addToggle) addToggle.addEventListener('click', function () { showAddForm = true; Forge.App.render(); });
    var cancelBtn = root.querySelector('#qNewCancel');
    if (cancelBtn) cancelBtn.addEventListener('click', function () { showAddForm = false; Forge.App.render(); });
    var submitBtn = root.querySelector('#qNewSubmit');
    if (submitBtn) submitBtn.addEventListener('click', function () {
      var title = root.querySelector('#qNewTitle').value.trim();
      if (!title) return;
      Forge.Engine.addCustomQuest(state, {
        title: title,
        flavor: root.querySelector('#qNewFlavor').value.trim(),
        area: root.querySelector('#qNewArea').value,
        stat: root.querySelector('#qNewStat').value,
        time: root.querySelector('#qNewTime').value.trim(),
        xp: parseInt(root.querySelector('#qNewXp').value, 10) || 15,
        repeat: root.querySelector('#qNewRepeat').checked
      });
      showAddForm = false;
      Forge.State.save();
      Forge.App.render();
    });
  }

  return { render: render, mount: mount };
})();

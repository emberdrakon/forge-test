// Daily Forge 2.0 — Settings
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Settings = (function () {
  var confirmingReset = false;
  var confirmingWipe = false;

  function render(state) {
    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Settings</div></div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Character</div>';
    html += '  <div class="forge-field"><label class="forge-label">Name</label><input class="forge-input" id="setName" maxlength="24" value="' + state.character.name + '" /></div>';
    html += '</div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Sound</div>';
    html += '  <label class="forge-checkline"><input type="checkbox" id="setSound"' + (state.settings.soundOn ? ' checked' : '') + ' /> Forge sound effects</label>';
    html += '</div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Cosmetics</div>';
    html += '  <div class="forge-col">';
    Forge.Data.COSMETICS.filter(function (c) { return c.kind === 'theme'; }).forEach(function (c) {
      var unlocked = state.crafting.unlockedCosmetics.indexOf(c.id) !== -1;
      var active = state.crafting.activeTheme === c.id;
      html += '<label class="forge-checkline" style="opacity:' + (unlocked ? '1' : '0.4') + '">' +
        '<input type="radio" name="theme" data-theme-pick="' + c.id + '"' + (active ? ' checked' : '') + (unlocked ? '' : ' disabled') + ' /> ' +
        c.name + (unlocked ? '' : ' (locked — craft it in Inventory)') + '</label>';
    });
    Forge.Data.COSMETICS.filter(function (c) { return c.kind === 'toggle'; }).forEach(function (c) {
      var unlocked = state.crafting.unlockedCosmetics.indexOf(c.id) !== -1;
      var active = !!state.crafting.activeToggles[c.id];
      html += '<label class="forge-checkline" style="opacity:' + (unlocked ? '1' : '0.4') + '">' +
        '<input type="checkbox" data-toggle-pick="' + c.id + '"' + (active ? ' checked' : '') + (unlocked ? '' : ' disabled') + ' /> ' +
        c.name + (unlocked ? '' : ' (locked — craft it in Inventory)') + '</label>';
    });
    html += '  </div>';
    html += '</div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Save Data</div>';
    html += '  <div class="forge-row" style="flex-wrap:wrap;">';
    html += '    <button class="forge-btn" id="setExport">' + Forge.Icons.svg('export') + ' Export Backup</button>';
    html += '    <label class="forge-btn" style="cursor:pointer;">' + Forge.Icons.svg('import') + ' Import Backup<input type="file" accept="application/json" id="setImport" style="display:none;" /></label>';
    html += '    <button class="forge-btn" id="setSignOut">Sign Out</button>';
    html += '  </div>';
    html += '</div>';

    html += '<div class="forge-panel forge-anim-in">';
    html += '  <div class="forge-panel-title">Danger Zone</div>';
    if (confirmingReset) {
      html += '<div style="font-size:12.5px;color:var(--text-dim);margin-bottom:8px;">Reset today’s quest log? XP and loot already earned stay banked.</div>';
      html += '<div class="forge-row"><button class="forge-btn forge-btn-ghost" id="resetCancel">Cancel</button><button class="forge-btn forge-btn-danger" id="resetConfirm">Confirm Reset</button></div>';
    } else {
      html += '<button class="forge-btn forge-btn-danger" id="resetToday">Reset Today’s Quest Log</button>';
    }
    html += '  <div class="forge-divider" style="margin:14px 0;"></div>';
    if (confirmingWipe) {
      html += '<div style="font-size:12.5px;color:var(--bad);margin-bottom:8px;">This erases your entire save permanently. Export a backup first.</div>';
      html += '<div class="forge-row"><button class="forge-btn forge-btn-ghost" id="wipeCancel">Cancel</button><button class="forge-btn forge-btn-danger" id="wipeConfirm">Erase Everything</button></div>';
    } else {
      html += '<button class="forge-btn forge-btn-danger" id="wipeAll">Erase Save</button>';
    }
    html += '</div>';

    html += '</div>';
    return html;
  }

  function mount(root, state) {
    var nameInput = root.querySelector('#setName');
    if (nameInput) nameInput.addEventListener('change', function () {
      state.character.name = nameInput.value.trim() || 'Wanderer';
      Forge.State.save();
      Forge.App.render();
    });

    var soundToggle = root.querySelector('#setSound');
    if (soundToggle) soundToggle.addEventListener('change', function () {
      state.settings.soundOn = soundToggle.checked;
      Forge.Sound.setEnabled(soundToggle.checked);
      Forge.State.save();
    });

    root.querySelectorAll('[data-theme-pick]').forEach(function (el) {
      el.addEventListener('change', function () {
        Forge.Engine.setActiveTheme(state, el.getAttribute('data-theme-pick'));
        Forge.State.save();
        Forge.App.applyCosmetics();
        Forge.App.render();
      });
    });
    root.querySelectorAll('[data-toggle-pick]').forEach(function (el) {
      el.addEventListener('change', function () {
        Forge.Engine.toggleCosmetic(state, el.getAttribute('data-toggle-pick'));
        Forge.State.save();
        Forge.App.applyCosmetics();
      });
    });

    var exportBtn = root.querySelector('#setExport');
    if (exportBtn) exportBtn.addEventListener('click', function () { Forge.Storage.exportBackup(state); });

    var importInput = root.querySelector('#setImport');
    if (importInput) importInput.addEventListener('change', function () {
      var file = importInput.files[0];
      if (!file) return;
      Forge.Storage.importBackup(file, function (err, data) {
        if (err) { Forge.UI.Toast.show('close', 'Import Failed', 'That file could not be read.'); return; }
        Forge.State.replace(data);
        Forge.State.save();
        Forge.State.flush().then(function () { Forge.App.restart(); });
      });
    });

    var resetToday = root.querySelector('#resetToday');
    if (resetToday) resetToday.addEventListener('click', function () { confirmingReset = true; Forge.App.render(); });
    var resetCancel = root.querySelector('#resetCancel');
    if (resetCancel) resetCancel.addEventListener('click', function () { confirmingReset = false; Forge.App.render(); });
    var resetConfirm = root.querySelector('#resetConfirm');
    if (resetConfirm) resetConfirm.addEventListener('click', function () {
      state.quests.instances.forEach(function (q) {
        if (q.date === state.today.date) { q.done = false; q.grantedLoot = null; q.grantedStat = null; q.grantedSkill = null; q.grantedXp = 0; }
      });
      confirmingReset = false;
      Forge.State.save();
      Forge.App.render();
    });

    var wipeAll = root.querySelector('#wipeAll');
    if (wipeAll) wipeAll.addEventListener('click', function () { confirmingWipe = true; Forge.App.render(); });
    var wipeCancel = root.querySelector('#wipeCancel');
    if (wipeCancel) wipeCancel.addEventListener('click', function () { confirmingWipe = false; Forge.App.render(); });
    var wipeConfirm = root.querySelector('#wipeConfirm');
    if (wipeConfirm) wipeConfirm.addEventListener('click', function () {
      Forge.State.replace(Forge.State.defaultState());
      Forge.State.save();
      confirmingWipe = false;
      Forge.State.flush().then(function () { Forge.App.restart(); });
    });

    var signOutBtn = root.querySelector('#setSignOut');
    if (signOutBtn) signOutBtn.addEventListener('click', function () {
      Forge.State.flush().then(function () {
        Forge.State.reset();
        Forge.Auth.signOut();
      });
    });
  }

  return { render: render, mount: mount };
})();

// Daily Forge 2.0 — Skill Trees
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Skills = (function () {
  function render(state) {
    var html = '<div class="forge-screen">';
    html += '<div class="forge-screen-head"><div class="forge-screen-title">Skill Trees</div><div class="forge-screen-sub">Grown slowly, over months.</div></div>';

    Forge.Data.SKILLS.forEach(function (s) {
      var xp = state.skills[s.id].xp;
      var info = Forge.Data.skillLevelInfo(xp);
      var lvl = info.level;
      var into = info.into;
      var per = info.per;
      html += '<div class="forge-panel forge-anim-in">';
      html += '  <div class="forge-row" style="justify-content:space-between;">';
      html += '    <span class="forge-stat-name">' + Forge.Icons.svg(s.icon) + s.name + '</span>';
      html += '    <span class="f-mono" style="color:var(--accent);">LV ' + lvl + '</span>';
      html += '  </div>';
      html += '  <div style="font-size:11.5px;color:var(--muted);margin:4px 0 8px;">' + s.desc + '</div>';
      html += '  <div class="forge-bar-track forge-bar-sm"><div class="forge-bar-fill forge-bar-sm" style="width:' + Math.round((into / per) * 100) + '%"></div></div>';
      html += '  <div style="font-size:10px;color:var(--muted);margin-top:4px;text-align:right;" class="f-mono">' + into + ' / ' + per + '</div>';
      html += '</div>';
    });

    html += '</div>';
    return html;
  }

  function mount() {}

  return { render: render, mount: mount };
})();

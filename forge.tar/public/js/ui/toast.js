// Daily Forge 2.0 — toast notifications, loot pop-ups, floating XP numbers
window.Forge = window.Forge || {};
Forge.UI = Forge.UI || {};

Forge.UI.Toast = (function () {
  var stackEl = null;

  function ensureStack() {
    if (stackEl) return stackEl;
    stackEl = document.createElement('div');
    stackEl.className = 'forge-toast-stack';
    document.querySelector('.forge-root').appendChild(stackEl);
    return stackEl;
  }

  function show(iconName, title, desc) {
    var stack = ensureStack();
    var el = document.createElement('div');
    el.className = 'forge-toast';
    el.innerHTML = Forge.Icons.svg(iconName) +
      '<div class="forge-toast-body"><div class="forge-toast-title">' + title + '</div><div class="forge-toast-desc">' + desc + '</div></div>';
    stack.appendChild(el);
    setTimeout(function () {
      el.classList.add('leaving');
      setTimeout(function () { el.remove(); }, 260);
    }, 3200);
  }

  function lootPopup(lootArr) {
    if (!lootArr || !lootArr.length) return;
    lootArr.forEach(function (l, i) {
      setTimeout(function () {
        var item = Forge.Data.getItem(l.id);
        if (!item) return;
        show(item.icon, 'Loot Found', item.name + ' x' + l.qty);
        Forge.Sound.play('loot');
      }, i * 260);
    });
  }

  function achievementPopup(ach) {
    show('trophy', 'Achievement Unlocked', ach.name);
    Forge.Sound.play('achievement');
  }

  function levelUpPopup(newLevel) {
    show('star', 'Level Up', 'You reached level ' + newLevel + '.');
    Forge.Sound.play('levelUp');
  }

  function xpFloat(fromEl, amount) {
    if (!fromEl) return;
    var rect = fromEl.getBoundingClientRect();
    var el = document.createElement('div');
    el.className = 'forge-xp-pop';
    el.style.left = (rect.left + rect.width / 2) + 'px';
    el.style.top = (rect.top) + 'px';
    el.textContent = '+' + amount + ' XP';
    document.body.appendChild(el);
    setTimeout(function () { el.remove(); }, 1000);
  }

  return { show: show, lootPopup: lootPopup, achievementPopup: achievementPopup, levelUpPopup: levelUpPopup, xpFloat: xpFloat };
})();
